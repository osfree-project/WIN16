#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "resources.h"
#include "memory.h"
#include "log.h"
#include "inf_parser.h"

void remove_disk_prefix(char *filename) {
    char *colon_pos = strchr(filename, ':');
    if (colon_pos != NULL) {
        memmove(filename, colon_pos + 1, strlen(colon_pos + 1) + 1);
    }
}

