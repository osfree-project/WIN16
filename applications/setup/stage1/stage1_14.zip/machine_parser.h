#ifndef MACHINE_PARSER_H
#define MACHINE_PARSER_H

#include "resources.h"

/* Machine configuration parsing */
void parse_machine_configuration(const char far *config_str, MachineEntry* entry, const char far *description);
void parse_all_machine_entries(void);

/* Machine entry management */
MachineEntry* get_machine_entry(int index);
int get_machine_entry_count(void);
void free_machine_entry(MachineEntry* entry);
void free_all_machine_entries(void);

#endif
