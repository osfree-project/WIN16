#ifndef INF_PARSER_H
#define INF_PARSER_H

#include "resources.h"
#include "setup_core.h"

/* Helper functions */
void remove_disk_prefix(char *filename);

/* INF file parsing */
void parse_inf_file(const SetupConfig* config);

/* Setup files management */
void add_setup_files(const SetupConfig* config);

/* Section files management */
void add_section_files(const char* section_name, const char* dest_dir, const SetupConfig* config);

#endif
