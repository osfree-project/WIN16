#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>
#include "resources.h"
#include "memory.h"
#include "log.h"
#include "inf_parser.h"
#include "file_list.h"

void remove_disk_prefix(char *filename) {
    char *colon_pos = strchr(filename, ':');
    if (colon_pos != NULL) {
        memmove(filename, colon_pos + 1, strlen(colon_pos + 1) + 1);
    }
}

/* Helper function to check if file should be copied based on condition */
static int should_copy_file(const char far *condition, const SetupConfig* config) {
    unsigned int cond_len;
    char *near_condition;
    int result;

    if (condition == NULL || condition[0] == '\0') {
        return 1; /* No condition - always copy */
    }
    
    /* Convert far condition to near string for comparison */
    cond_len = _fstrlen(condition);
    near_condition = (char*)xmalloc(cond_len + 1);
    if (near_condition) {
        _fstrcpy(near_condition, condition);
    } else {
        return 0; /* Out of memory - skip file */
    }
    
    result = 0;
    
    if (strcmp(near_condition, "Net") == 0) {
        /* Copy only for administrative setup */
        result = config->admin_setup;
        log_message("File condition 'Net': copying only for admin setup (admin_setup=%d)", config->admin_setup);
    } else {
        /* Copy if condition matches selected network */
        result = (strcmp(near_condition, config->selected_network) == 0);
        log_message("File condition '%s': copying only for network '%s' (selected_network=%s)", 
                   near_condition, near_condition, config->selected_network);
    }
    
    xfree(near_condition);
    return result;
}

/* Simple parser for file copy sections like [windows] and [windows.system] */
static void parse_file_copy_line(const char* line, char* source, char* condition) {
    char line_copy[256];
    char *comma_pos;
    char *temp;
    char *end_ptr;
    
    source[0] = '\0';
    condition[0] = '\0';
    
    if (!line || strlen(line) == 0) return;
    
    /* Make a working copy */
    strncpy(line_copy, line, sizeof(line_copy) - 1);
    line_copy[sizeof(line_copy) - 1] = '\0';
    
    /* Skip empty lines and comments */
    temp = line_copy;
    while (*temp && isspace((unsigned char)*temp)) temp++;
    if (*temp == '\0' || *temp == ';') return;
    
    /* Trim the line */
    end_ptr = line_copy + strlen(line_copy) - 1;
    while (end_ptr > line_copy && isspace((unsigned char)*end_ptr)) {
        *end_ptr = '\0';
        end_ptr--;
    }
    
    /* Find comma separator for condition */
    comma_pos = strchr(line_copy, ',');
    
    if (comma_pos) {
        /* Split into source and condition */
        *comma_pos = '\0';
        
        /* Trim source part */
        temp = line_copy;
        while (*temp && isspace((unsigned char)*temp)) temp++;
        end_ptr = temp + strlen(temp) - 1;
        while (end_ptr > temp && isspace((unsigned char)*end_ptr)) {
            *end_ptr = '\0';
            end_ptr--;
        }
        strcpy(source, temp);
        
        /* Trim condition part */
        temp = comma_pos + 1;
        while (*temp && isspace((unsigned char)*temp)) temp++;
        end_ptr = temp + strlen(temp) - 1;
        while (end_ptr > temp && isspace((unsigned char)*end_ptr)) {
            *end_ptr = '\0';
            end_ptr--;
        }
        strcpy(condition, temp);
    } else {
        /* No condition - just source */
        temp = line_copy;
        while (*temp && isspace((unsigned char)*temp)) temp++;
        end_ptr = temp + strlen(temp) - 1;
        while (end_ptr > temp && isspace((unsigned char)*end_ptr)) {
            *end_ptr = '\0';
            end_ptr--;
        }
        strcpy(source, temp);
    }
}

void add_setup_files(const SetupConfig* config) {
    log_message("add_setup_files: Adding setup files to copy list");
    
    if (!config) {
        log_message("add_setup_files: ERROR - null config");
        return;
    }
    
    /* Add SETUP.EXE file - disk 1 */
    file_list_add_entry('1', "SETUP.EXE", config->windowsDir, "SETUP.EXE");
    
    /* Add INF file - pseudo disk -1 with full source path */
    file_list_add_entry(-1, config->inf_filename, config->systemDir, "SETUP.INF");
    
    log_message("add_setup_files: Setup files added to copy list");
}

void add_section_files(const char* section_name, const char* dest_dir, const SetupConfig* config) {
    char far * far *lines;
    int line_count;
    int i;
    char line_copy[256];
    char source[256];
    char condition[256];
    char filename_only[256];
    char dest_filename[256];
    char disk_char;
    
    if (get_section_lines(section_name, &lines, &line_count)) {
        log_message("add_section_files: Adding files from [%s] section to %s directory", section_name, dest_dir);
        for (i = 0; i < line_count; i++) {
            if (!lines[i]) continue;
            
            /* Parse the line for file copy sections */
            source[0] = '\0';
            condition[0] = '\0';
            
            _fstrncpy(line_copy, lines[i], sizeof(line_copy) - 1);
            line_copy[sizeof(line_copy) - 1] = '\0';
            
            parse_file_copy_line(line_copy, source, condition);
            
            if (source[0] != '\0') {
                /* Check condition */
                if (condition[0] != '\0' && !should_copy_file((const char far*)condition, config)) {
                    log_message("add_section_files: Skipping file due to condition '%s': %s", condition, source);
                    continue; /* Skip file due to condition */
                }
                
                /* Extract disk number and filename from source */
                disk_char = '1'; /* Default disk */
                strcpy(filename_only, source);
                strcpy(dest_filename, source);
                
                /* Remove disk prefix from source and destination names */
                remove_disk_prefix(filename_only);
                remove_disk_prefix(dest_filename);
                
                /* Extract actual disk number if present */
                if (strchr(source, ':') != NULL) {
                    disk_char = source[0];
                    if (disk_char < '0' || disk_char > '9') {
                        disk_char = '1'; /* Invalid disk, use default */
                    }
                }
                
                /* Add to file list */
                file_list_add_entry(disk_char, filename_only, dest_dir, dest_filename);
                
                log_message("add_section_files: Added file - disk: %c, source: '%s', dest: '%s'", 
                           disk_char, filename_only, dest_filename);
            }
        }
        _ffree(lines);
    } else {
        log_message("add_section_files: Warning: [%s] section not found in INF file", section_name);
    }
}

void parse_inf_file(const SetupConfig* config) {
    log_message("parse_inf_file: Starting INF file parsing");
    
    if (!config) {
        log_message("parse_inf_file: ERROR - null config");
        return;
    }
    
    /* Add setup files to copy list */
    add_setup_files(config);
    
    /* Add files from windows.system section */
    add_section_files("windows.system", config->systemDir, config);
    
    /* Add files from windows section */
    add_section_files("windows", config->windowsDir, config);
    
    /* Add CPU-specific sections for 386 */
    if (config->cpu_type == 2) { /* CPU_386 */
        add_section_files("windows.system.386", config->systemDir, config);
    }
    
    /* Dump file list contents for verification */
    file_list_dump();
    
    log_message("parse_inf_file: INF file parsing completed");
}
