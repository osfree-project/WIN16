#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include "display_list.h"
#include "log.h"

static DisplayEntry *display_list_head = NULL;
static int display_list_size = 0;

void display_list_init(void) {
    display_list_clear();
}

void display_list_add(const char* name, const char* driver_file, const char* description,
                     const char* resolution, const char* grabber_286, const char* logo_code,
                     const char* vdd_file, const char* grabber_386, const char* ega_sys,
                     const char* logo_data) {
    DisplayEntry *new_entry;
    DisplayEntry *current;
    
    /* Create new entry */
    new_entry = (DisplayEntry*)malloc(sizeof(DisplayEntry));
    if (!new_entry) {
        log_message("display_list_add: Memory allocation failed");
        return;
    }
    
    /* Initialize fields */
    strncpy(new_entry->name, name, MAX_DISPLAY_FIELD_LENGTH - 1);
    new_entry->name[MAX_DISPLAY_FIELD_LENGTH - 1] = '\0';
    
    strncpy(new_entry->driver_file, driver_file, MAX_DISPLAY_FIELD_LENGTH - 1);
    new_entry->driver_file[MAX_DISPLAY_FIELD_LENGTH - 1] = '\0';
    
    strncpy(new_entry->description, description, MAX_DISPLAY_DESCRIPTION_LENGTH - 1);
    new_entry->description[MAX_DISPLAY_DESCRIPTION_LENGTH - 1] = '\0';
    
    strncpy(new_entry->resolution, resolution, MAX_DISPLAY_FIELD_LENGTH - 1);
    new_entry->resolution[MAX_DISPLAY_FIELD_LENGTH - 1] = '\0';
    
    strncpy(new_entry->grabber_286, grabber_286, MAX_DISPLAY_FIELD_LENGTH - 1);
    new_entry->grabber_286[MAX_DISPLAY_FIELD_LENGTH - 1] = '\0';
    
    strncpy(new_entry->logo_code, logo_code, MAX_DISPLAY_FIELD_LENGTH - 1);
    new_entry->logo_code[MAX_DISPLAY_FIELD_LENGTH - 1] = '\0';
    
    strncpy(new_entry->vdd_file, vdd_file, MAX_DISPLAY_FIELD_LENGTH - 1);
    new_entry->vdd_file[MAX_DISPLAY_FIELD_LENGTH - 1] = '\0';
    
    strncpy(new_entry->grabber_386, grabber_386, MAX_DISPLAY_FIELD_LENGTH - 1);
    new_entry->grabber_386[MAX_DISPLAY_FIELD_LENGTH - 1] = '\0';
    
    strncpy(new_entry->ega_sys, ega_sys, MAX_DISPLAY_FIELD_LENGTH - 1);
    new_entry->ega_sys[MAX_DISPLAY_FIELD_LENGTH - 1] = '\0';
    
    strncpy(new_entry->logo_data, logo_data, MAX_DISPLAY_FIELD_LENGTH - 1);
    new_entry->logo_data[MAX_DISPLAY_FIELD_LENGTH - 1] = '\0';
    
    new_entry->next = NULL;
    
    /* Add to list */
    if (display_list_head == NULL) {
        display_list_head = new_entry;
    } else {
        current = display_list_head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = new_entry;
    }
    
    display_list_size++;
    log_message("display_list_add: Added display '%s', total entries: %d", name, display_list_size);
}

DisplayEntry* display_list_find(const char* name) {
    DisplayEntry *current = display_list_head;
    
    while (current != NULL) {
        if (strcmp(current->name, name) == 0) {
            return current;
        }
        current = current->next;
    }
    
    return NULL;
}

int display_list_count(void) {
    return display_list_size;
}

void display_list_clear(void) {
    DisplayEntry *current = display_list_head;
    DisplayEntry *next;
    
    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }
    
    display_list_head = NULL;
    display_list_size = 0;
    log_message("display_list_clear: Display list cleared");
}

void display_list_free(void) {
    display_list_clear();
}
