#ifndef DISK_LIST_H
#define DISK_LIST_H

#define MAX_VALUE_LENGTH 300

typedef struct DiskInfo {
    char disk;
    char path[MAX_VALUE_LENGTH];
    char label[MAX_VALUE_LENGTH];
    char tag[MAX_VALUE_LENGTH];
    struct DiskInfo *next;
} DiskInfo;

/* Disk list operations */
void disk_list_add(char disk, const char* path, const char* label, const char* tag);
DiskInfo* disk_list_find(char disk);
void disk_list_free_all(void);

/* Disk information getters */
char* get_disk_path(char disk);
char* get_disk_label(char disk);
char* get_disk_tag(char disk);

#endif
