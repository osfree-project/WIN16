#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "disk_list.h"
#include "log.h"

static DiskInfo *disk_list_head = NULL;

void disk_list_add(char disk, const char* path, const char* label, const char* tag) {
    DiskInfo *new_disk;
    
//    log_message("disk_list_add: Adding disk %c: path='%s', label='%s', tag='%s'", 
//                disk, path, label, tag);
    
    /* Create new disk entry */
    new_disk = (DiskInfo *)malloc(sizeof(DiskInfo));
    if (!new_disk) {
        log_message("disk_list_add: ERROR - memory allocation failed");
        return;
    }
    
    new_disk->disk = disk;
    
    if (path) {
        strncpy(new_disk->path, path, MAX_VALUE_LENGTH - 1);
        new_disk->path[MAX_VALUE_LENGTH - 1] = '\0';
    } else {
        new_disk->path[0] = '\0';
    }
    
    if (label) {
        strncpy(new_disk->label, label, MAX_VALUE_LENGTH - 1);
        new_disk->label[MAX_VALUE_LENGTH - 1] = '\0';
    } else {
        new_disk->label[0] = '\0';
    }
    
    if (tag) {
        strncpy(new_disk->tag, tag, MAX_VALUE_LENGTH - 1);
        new_disk->tag[MAX_VALUE_LENGTH - 1] = '\0';
    } else {
        new_disk->tag[0] = '\0';
    }
    
    /* Add to linked list */
    new_disk->next = disk_list_head;
    disk_list_head = new_disk;
    
//    log_message("disk_list_add: Disk %c added successfully", disk);
}

DiskInfo* disk_list_find(char disk) {
    DiskInfo *current = disk_list_head;
    
    while (current != NULL) {
        if (current->disk == disk) {
            return current;
        }
        current = current->next;
    }
    
    return NULL;
}

void disk_list_free_all(void) {
    DiskInfo *current = disk_list_head;
    DiskInfo *next;
    int count = 0;
    
//    log_message("disk_list_free_all: Freeing disk list");
    
    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
        count++;
    }
    
    disk_list_head = NULL;
//    log_message("disk_list_free_all: Freed %d disk entries", count);
}

char* get_disk_path(char disk) {
    DiskInfo* info;
    char* result;
    
    info = disk_list_find(disk);
    if (info && info->path[0]) {
        result = (char*)malloc(strlen(info->path) + 1);
        if (result) {
            strcpy(result, info->path);
        }
        return result;
    }
    return NULL;
}

char* get_disk_label(char disk) {
    DiskInfo* info;
    char* result;
    
    info = disk_list_find(disk);
    if (info && info->label[0]) {
        result = (char*)malloc(strlen(info->label) + 1);
        if (result) {
            strcpy(result, info->label);
        }
        return result;
    }
    return NULL;
}

char* get_disk_tag(char disk) {
    DiskInfo* info;
    char* result;
    
    info = disk_list_find(disk);
    if (info && info->tag[0]) {
        result = (char*)malloc(strlen(info->tag) + 1);
        if (result) {
            strcpy(result, info->tag);
        }
        return result;
    }
    return NULL;
}
