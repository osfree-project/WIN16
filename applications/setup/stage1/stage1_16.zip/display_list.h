#ifndef DISPLAY_LIST_H
#define DISPLAY_LIST_H

#define MAX_DISPLAY_FIELD_LENGTH 100
#define MAX_DISPLAY_DESCRIPTION_LENGTH 256

typedef struct DisplayEntry {
    char name[MAX_DISPLAY_FIELD_LENGTH];
    char driver_file[MAX_DISPLAY_FIELD_LENGTH];
    char description[MAX_DISPLAY_DESCRIPTION_LENGTH];
    char resolution[MAX_DISPLAY_FIELD_LENGTH];
    char grabber_286[MAX_DISPLAY_FIELD_LENGTH];
    char logo_code[MAX_DISPLAY_FIELD_LENGTH];
    char vdd_file[MAX_DISPLAY_FIELD_LENGTH];
    char grabber_386[MAX_DISPLAY_FIELD_LENGTH];
    char ega_sys[MAX_DISPLAY_FIELD_LENGTH];
    char logo_data[MAX_DISPLAY_FIELD_LENGTH];
    struct DisplayEntry *next;
} DisplayEntry;

/* Display list operations */
void display_list_init(void);
void display_list_add(const char* name, const char* driver_file, const char* description,
                     const char* resolution, const char* grabber_286, const char* logo_code,
                     const char* vdd_file, const char* grabber_386, const char* ega_sys,
                     const char* logo_data);
DisplayEntry* display_list_find(const char* name);
int display_list_count(void);
void display_list_clear(void);
void display_list_free(void);

#endif
