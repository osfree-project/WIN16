#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include "memory.h"

void far * far xfarmalloc(unsigned long size) {
    void far *ptr = _fmalloc(size);
    if (!ptr) {
        printf("Fatal error: Out of far memory (%lu bytes)\n", size);
        exit(1);
    }
    return ptr;
}

void far xfarfree(void far *ptr) {
    if (ptr) _ffree(ptr);
}

void* xmalloc(size_t size) {
    void* ptr = malloc(size);
    if (!ptr) {
        printf("Fatal error: Out of memory (%u bytes)\n", (unsigned)size);
        exit(1);
    }
    return ptr;
}

void xfree(void *ptr) {
    if (ptr) free(ptr);
}

char* xstrdup(const char *str) {
    char *newstr;
    
    if (!str) return NULL;
    newstr = (char*)xmalloc(strlen(str) + 1);
    strcpy(newstr, str);
    return newstr;
}
