#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "setup_core.h"
#include "resources.h"
#include "system_info.h"
#include "file_utils.h"
#include "log.h"
#include "ui.h"
#include "dialog.h"
#include "screens.h"

int main(int argc, char *argv[]) {
    SetupConfig config;
    int setup_type = 0;
    char temp_dir[80];
    
    /* Initialize configuration */
    setup_config_init(&config);
    
    /* Parse command line */
    parse_command_line(argc, argv, &config);
    
    /* Initialize logging */
    log_init(config.logFile);
    
    /* Initialize UI */
    init_ui();
    
    /* Display welcome screen */
    setup_welcome();
    
    /* Detect hardware */
    if (!config.ignore_autodetect) {
        config.cpu_type = detect_cpu_type();
        log_message("Detected CPU type: %d", config.cpu_type);
    }
    
    /* Display setup type menu */
    setup_type = setup_type_menu();
    
    /* Get installation directory */
    setup_directory_menu(config.windowsDir);
    
    /* Update system directories based on windows directory */
    sprintf(config.systemDir, "%s\\SYSTEM", config.windowsDir);
    sprintf(config.tempDir, "%s\\TEMP", config.windowsDir);
    
    /* Load INF file */
    if (config.inf_filename[0] == '\0') {
        strcpy(config.inf_filename, "SETUP.INF");
    }
    load_inf_file(config.inf_filename);
    
    /* Select network if needed */
    if (config.network_setup) {
        select_network(&config);
    }
    
    /* Detect setup mode */
    detect_setup_mode(&config);
    
    /* Check disk space */
    check_disk_space(&config);
    
    /* Display configuration confirmation */
    display_configuration_confirmation(config.windowsDir, 
                                      setup_type == 0 ? "Express" : 
                                      setup_type == 1 ? "Custom" : "Minimum");
    
    /* Setup directories */
    setup_directories(&config);
    
    /* Show loading screen */
    setup_loading_screen();
    
    /* Copy files */
    if (!copy_files(&config)) {
        log_message("File copy failed");
        display_error_dialog("File copy failed.", "Please check the log file", "for details.");
        return 1;
    }
    
    /* Update configuration */
    update_autoexec_bat(&config);
    update_config_sys();
    setup_configuration(&config);
    
    /* Display completion screen */
    display_completion_screen();
    
    /* Launch stage 2 */
    launch_stage2(&config);
    
    /* Cleanup */
    free_resources();
    log_close();
    
    return 0;
}
