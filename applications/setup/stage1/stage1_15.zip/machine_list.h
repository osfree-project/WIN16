#ifndef MACHINE_LIST_H
#define MACHINE_LIST_H

#include "resources.h"

/* Dynamic machine list structure */
typedef struct MachineListNode {
    MachineEntry entry;
    struct MachineListNode *next;
} MachineListNode;

/* Machine list operations */
void machine_list_init(void);
void machine_list_add(const MachineEntry *entry);
MachineEntry* machine_list_get(int index);
int machine_list_count(void);
void machine_list_clear(void);
void machine_list_free(void);

#endif
