#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>
#include "resources.h"
#include "memory.h"
#include "log.h"

static DiskInfo disk_info[MAX_DISKS];
static int disk_count = 0;

static InfSection sections[MAX_SECTIONS];
static int section_count = 0;
static char current_language[MAX_LANGUAGE_LENGTH] = "usa";

/* Helper function to duplicate string to far memory */
static char far * far_strdup(const char *str) {
    unsigned int len;
    const char *src;
    char far *dst;
    char far *far_str;
    
    if (!str) return NULL;
    
    /* Calculate length manually to avoid size_t issues */
    len = 0;
    src = str;
    while (*src++) len++;
    
    far_str = (char far *)xfarmalloc(len + 1);
    if (far_str) {
        src = str;
        dst = far_str;
        while (len--) {
            *dst++ = *src++;
        }
        *dst = '\0';
    }
    return far_str;
}

/* Helper function to remove disk prefix from filename */
static void remove_disk_prefix(char *filename) {
    char *colon_pos = strchr(filename, ':');
    if (colon_pos != NULL) {
        /* Move the part after colon to beginning */
        memmove(filename, colon_pos + 1, strlen(colon_pos + 1) + 1);
    }
}

/* Helper function to parse file list line (format: "source" or "source,condition") */
static void parse_file_list_line(char *line, char *key, char *value, char *condition, int max_len) {
    char *comma_pos;
    char *temp;
    
    /* Initialize */
    key[0] = '\0';
    value[0] = '\0';
    if (condition) condition[0] = '\0';
    
    /* Trim leading and trailing whitespace from the entire line first */
    temp = line;
    while (*temp && isspace((unsigned char)*temp)) temp++;
    if (temp != line) {
        memmove(line, temp, strlen(temp) + 1);
    }
    temp = line + strlen(line) - 1;
    while (temp > line && isspace((unsigned char)*temp)) {
        *temp = '\0';
        temp--;
    }
    
    /* Skip empty lines after trimming */
    if (strlen(line) == 0) {
        return;
    }
    
    /* Find comma separator */
    comma_pos = strchr(line, ',');
    
    if (comma_pos != NULL) {
        /* Format: source,condition */
        *comma_pos = '\0';
        
        /* Source file (key) - part before comma */
        strncpy(key, line, max_len - 1);
        key[max_len - 1] = '\0';
        
        /* Condition is after comma */
        if (condition) {
            strncpy(condition, comma_pos + 1, max_len - 1);
            condition[max_len - 1] = '\0';
        }
    } else {
        /* Format: source (no condition) */
        strncpy(key, line, max_len - 1);
        key[max_len - 1] = '\0';
    }
    
    /* Remove disk prefixes from key */
    remove_disk_prefix(key);
    
    /* Trim whitespace from key */
    temp = key;
    while (*temp && isspace((unsigned char)*temp)) temp++;
    if (temp != key) {
        memmove(key, temp, strlen(temp) + 1);
    }
    temp = key + strlen(key) - 1;
    while (temp > key && isspace((unsigned char)*temp)) {
        *temp = '\0';
        temp--;
    }
    
    /* For file list sections, value should be the same as key (same filename) */
    if (strlen(key) > 0 && strlen(value) == 0) {
        strcpy(value, key);
    }
    
    /* Trim whitespace from condition if present */
    if (condition && condition[0] != '\0') {
        temp = condition;
        while (*temp && isspace((unsigned char)*temp)) temp++;
        if (temp != condition) {
            memmove(condition, temp, strlen(temp) + 1);
        }
        temp = condition + strlen(condition) - 1;
        while (temp > condition && isspace((unsigned char)*temp)) {
            *temp = '\0';
            temp--;
        }
    }
}

/* Improved helper function to parse machine section lines */
static void parse_machine_line(char *line, char *description, char *config, int max_len) {
    char *temp;
    char *first_quote;
    char *second_quote;
    char *third_quote;
    char *fourth_quote;
    
    /* Initialize */
    description[0] = '\0';
    config[0] = '\0';
    
    /* Trim leading and trailing whitespace */
    temp = line;
    while (*temp && isspace((unsigned char)*temp)) temp++;
    if (temp != line) {
        memmove(line, temp, strlen(temp) + 1);
    }
    temp = line + strlen(line) - 1;
    while (temp > line && isspace((unsigned char)*temp)) {
        *temp = '\0';
        temp--;
    }
    
    /* Skip empty lines */
    if (strlen(line) == 0) {
        return;
    }
    
    /* Machine lines have format: "description","machine_id" followed by configuration lines */
    if (line[0] == '"') {
        first_quote = line;
        second_quote = strchr(first_quote + 1, '"');
        if (second_quote) {
            /* Extract description between first and second quote */
            int desc_len = second_quote - (first_quote + 1);
            if (desc_len > 0 && desc_len < max_len) {
                strncpy(description, first_quote + 1, desc_len);
                description[desc_len] = '\0';
            }
            
            /* Look for machine ID after the description */
            third_quote = strchr(second_quote + 1, '"');
            if (third_quote) {
                fourth_quote = strchr(third_quote + 1, '"');
                if (fourth_quote) {
                    /* Machine ID found between third and fourth quote */
                    /* For machine section, we use the entire line as the key */
                    strncpy(config, line, max_len - 1);
                    config[max_len - 1] = '\0';
                } else {
                    /* No closing quote for machine ID, use entire line */
                    strncpy(config, line, max_len - 1);
                    config[max_len - 1] = '\0';
                }
            } else {
                /* No machine ID found, use entire line */
                strncpy(config, line, max_len - 1);
                config[max_len - 1] = '\0';
            }
        } else {
            /* No closing quote for description, use entire line */
            strncpy(config, line, max_len - 1);
            config[max_len - 1] = '\0';
        }
    } else {
        /* Configuration line (not the description line) - this is the actual machine configuration */
        strncpy(config, line, max_len - 1);
        config[max_len - 1] = '\0';
    }
}

void load_inf_file(const char* filename) {
    FILE* file;
    char line[512];
    char current_section[100] = "";
    InfSection* current_section_ptr = NULL;
    char* pos;
    char* equal_sign;
    char* key_ptr;
    char* value_ptr;
    char* temp;
    StringResource far *res;
    int i, j;
    int new_alloc;
    StringResource far *new_lines;
    char key_buf[MAX_KEY_LENGTH];
    char value_buf[MAX_VALUE_LENGTH];
    char condition_buf[MAX_VALUE_LENGTH];
    char machine_desc[256];
    char machine_config[256];
    int in_machine_section = 0;
    char disk_char;
    char path[300], label[300], tag[300];
    int scan_count;
    int section_index;
    
    /* Variables for machine section parsing */
    char far *old_value;
    unsigned int old_len, line_len, new_len;
    char far *new_value;
    
    /* Variables for disk parsing */
    char *path_start, *label_start, *tag_start;
    char *comma1, *comma2;
    
    /* Variables for line trimming */
    char *trimmed_line;
    char *end_ptr;
    
    log_message("Loading INF file: %s", filename);
    
    /* Clear existing sections */
    for (i = 0; i < section_count; i++) {
        if (sections[i].lines) {
            for (j = 0; j < sections[i].line_count; j++) {
                if (sections[i].lines[j].key) {
                    xfarfree(sections[i].lines[j].key);
                }
                if (sections[i].lines[j].value) {
                    xfarfree(sections[i].lines[j].value);
                }
                if (sections[i].lines[j].condition) {
                    xfarfree(sections[i].lines[j].condition);
                }
            }
            xfarfree(sections[i].lines);
        }
    }
    section_count = 0;
    disk_count = 0;
    
    file = fopen(filename, "rt");
    if (!file) {
        log_message("Error: Cannot open INF file: %s", filename);
        return;
    }

    while (fgets(line, sizeof(line), file)) {
        /* Remove newline characters */
        line[strcspn(line, "\r\n")] = '\0';
        
        /* Trim leading and trailing whitespace */
        trimmed_line = line;
        while (*trimmed_line && isspace((unsigned char)*trimmed_line)) trimmed_line++;
        end_ptr = trimmed_line + strlen(trimmed_line) - 1;
        while (end_ptr > trimmed_line && isspace((unsigned char)*end_ptr)) {
            *end_ptr = '\0';
            end_ptr--;
        }
        
        /* Skip empty lines and comments */
        if (trimmed_line[0] == '\0' || trimmed_line[0] == ';') {
            continue;
        }

        /* Check for section header */
        if (trimmed_line[0] == '[') {
            pos = strchr(trimmed_line, ']');
            if (pos) {
                *pos = '\0';
                strncpy(current_section, trimmed_line + 1, sizeof(current_section) - 1);
                current_section[sizeof(current_section) - 1] = '\0';
                
                log_message("Found section: [%s]", current_section);
                
                /* Reset machine section state */
                in_machine_section = (strcmp(current_section, "machine") == 0);
                
                /* Find or create section */
                current_section_ptr = NULL;
                for (section_index = 0; section_index < section_count; section_index++) {
                    if (strcmp(sections[section_index].name, current_section) == 0) {
                        current_section_ptr = &sections[section_index];
                        break;
                    }
                }
                
                if (!current_section_ptr && section_count < MAX_SECTIONS) {
                    current_section_ptr = &sections[section_count];
                    strncpy(current_section_ptr->name, current_section, 
                           sizeof(current_section_ptr->name) - 1);
                    current_section_ptr->name[sizeof(current_section_ptr->name) - 1] = '\0';
                    current_section_ptr->lines = NULL;
                    current_section_ptr->line_count = 0;
                    current_section_ptr->lines_allocated = 0;
                    section_count++;
                    log_message("Created new section: [%s], total sections: %d", current_section, section_count);
                } else if (current_section_ptr) {
                    log_message("Using existing section: [%s]", current_section);
                } else {
                    log_message("Warning: Maximum sections reached, cannot create section: [%s]", current_section);
                }
            }
            continue;
        }

        /* Process disks section - FIXED: ������ ��������� ������ ����� */
        if (strcmp(current_section, "disks") == 0 && current_section_ptr) {
            if (disk_count < MAX_DISKS) {
                /* Parse disk line format: n = path,"disk name","disk tag" */
                /* ���������� ������� ��� ��������� ������� */
                
                /* ������� ������ ���� ��������� */
                equal_sign = strchr(trimmed_line, '=');
                if (!equal_sign) continue;
                
                /* �������� ������ ����� */
                disk_char = trimmed_line[0];
                
                /* ���������� ������� ����� = */
                path_start = equal_sign + 1;
                while (*path_start && isspace((unsigned char)*path_start)) path_start++;
                
                /* ������� ������ ������� */
                comma1 = strchr(path_start, ',');
                if (!comma1) continue;
                *comma1 = '\0';
                
                /* ������� ������ ����� */
                label_start = comma1 + 1;
                while (*label_start && isspace((unsigned char)*label_start)) label_start++;
                
                /* ������� ������ ������� */
                comma2 = strchr(label_start, ',');
                if (!comma2) continue;
                *comma2 = '\0';
                
                /* ������� ������ ���� */
                tag_start = comma2 + 1;
                while (*tag_start && isspace((unsigned char)*tag_start)) tag_start++;
                
                /* �������� ���� */
                strncpy(path, path_start, sizeof(path)-1);
                path[sizeof(path)-1] = '\0';
                
                /* ������� ������� �� ����� ���� ���� */
                strncpy(label, label_start, sizeof(label)-1);
                label[sizeof(label)-1] = '\0';
                if (label[0] == '"' && label[strlen(label)-1] == '"') {
                    memmove(label, label+1, strlen(label)-2);
                    label[strlen(label)-2] = '\0';
                }
                
                /* ������� ������� �� ���� ���� ���� */
                strncpy(tag, tag_start, sizeof(tag)-1);
                tag[sizeof(tag)-1] = '\0';
                if (tag[0] == '"' && tag[strlen(tag)-1] == '"') {
                    memmove(tag, tag+1, strlen(tag)-2);
                    tag[strlen(tag)-2] = '\0';
                }
                
                /* ���������� ������� */
                temp = path;
                while (*temp && isspace((unsigned char)*temp)) temp++;
                if (temp != path) {
                    strcpy(path, temp);
                }
                temp = path + strlen(path) - 1;
                while (temp > path && isspace((unsigned char)*temp)) {
                    *temp = '\0';
                    temp--;
                }
                
                disk_info[disk_count].disk = disk_char;
                strncpy(disk_info[disk_count].path, path, sizeof(disk_info[disk_count].path)-1);
                disk_info[disk_count].path[sizeof(disk_info[disk_count].path)-1] = '\0';
                strncpy(disk_info[disk_count].label, label, sizeof(disk_info[disk_count].label)-1);
                disk_info[disk_count].label[sizeof(disk_info[disk_count].label)-1] = '\0';
                strncpy(disk_info[disk_count].tag, tag, sizeof(disk_info[disk_count].tag)-1);
                disk_info[disk_count].tag[sizeof(disk_info[disk_count].tag)-1] = '\0';
                disk_count++;
                log_message("Added disk: %c -> %s, label: %s, tag: %s", disk_char, path, label, tag);
                
                /* ����� ��������� � ������ ��� ����-�������� */
                if (current_section_ptr->line_count >= current_section_ptr->lines_allocated) {
                    new_alloc = current_section_ptr->lines_allocated == 0 ? 10 : current_section_ptr->lines_allocated * 2;
                    new_lines = (StringResource far *)xfarmalloc(new_alloc * sizeof(StringResource));
                    if (new_lines) {
                        if (current_section_ptr->lines) {
                            _fmemcpy(new_lines, current_section_ptr->lines, 
                                    current_section_ptr->line_count * sizeof(StringResource));
                            xfarfree(current_section_ptr->lines);
                        }
                        current_section_ptr->lines = new_lines;
                        current_section_ptr->lines_allocated = new_alloc;
                    }
                }
                
                if (current_section_ptr->line_count < current_section_ptr->lines_allocated) {
                    char disk_key[10];
                    char disk_value[300];
                    
                    sprintf(disk_key, "%c", disk_char);
                    sprintf(disk_value, "%s,%s,%s", path, label, tag);
                    
                    res = &current_section_ptr->lines[current_section_ptr->line_count];
                    res->key = far_strdup(disk_key);
                    res->value = far_strdup(disk_value);
                    res->condition = NULL;
                    
                    if (res->key && res->value) {
                        current_section_ptr->line_count++;
                    } else {
                        if (res->key) xfarfree(res->key);
                        if (res->value) xfarfree(res->value);
                    }
                }
            }
            continue;
        }

        /* Special handling for machine section - FIXED: ���������� ������� � ������ �������� */
        if (in_machine_section && current_section_ptr) {
            /* Check if this line starts a new machine entry (starts with quote and contains comma) */
            if (trimmed_line[0] == '"' && strchr(trimmed_line, ',') != NULL) {
                /* This is a new machine entry */
                machine_desc[0] = '\0';
                machine_config[0] = '\0';
                parse_machine_line(trimmed_line, machine_desc, machine_config, sizeof(machine_config));
                
                /* Skip if description is empty */
                if (strlen(machine_desc) == 0) {
                    continue;
                }
                
                /* Allocate more memory if needed */
                if (current_section_ptr->line_count >= current_section_ptr->lines_allocated) {
                    new_alloc = current_section_ptr->lines_allocated == 0 ? 20 : current_section_ptr->lines_allocated * 2;
                    if (new_alloc > MAX_LINES) {
                        new_alloc = MAX_LINES;
                    }
                    
                    new_lines = (StringResource far *)xfarmalloc(new_alloc * sizeof(StringResource));
                    if (!new_lines) {
                        log_message("Warning: Out of memory for machine section");
                        continue; /* Out of memory */
                    }
                    
                    if (current_section_ptr->lines) {
                        _fmemcpy(new_lines, current_section_ptr->lines, 
                                current_section_ptr->line_count * sizeof(StringResource));
                        xfarfree(current_section_ptr->lines);
                    }
                    
                    current_section_ptr->lines = new_lines;
                    current_section_ptr->lines_allocated = new_alloc;
                }
                
                if (current_section_ptr->line_count < current_section_ptr->lines_allocated) {
                    /* Add machine description as key and the configuration line as value */
                    res = &current_section_ptr->lines[current_section_ptr->line_count];
                    res->key = far_strdup(machine_desc);
                    res->value = far_strdup(machine_config); /* Store the first configuration line */
                    res->condition = NULL;
                    
                    if (res->key && res->value) {
                        current_section_ptr->line_count++;
                        log_message("Added machine entry: %s -> %s", machine_desc, machine_config);
                    } else {
                        /* Cleanup if allocation failed */
                        log_message("Warning: Failed to allocate memory for machine entry");
                        if (res->key) xfarfree(res->key);
                        if (res->value) xfarfree(res->value);
                    }
                }
            } else {
                /* This is a continuation line for the current machine */
                if (current_section_ptr->line_count > 0) {
                    res = &current_section_ptr->lines[current_section_ptr->line_count - 1];
                    
                    /* Append this line to the existing value */
                    old_value = res->value;
                    old_len = old_value ? _fstrlen(old_value) : 0;
                    line_len = strlen(trimmed_line);
                    new_len = old_len + line_len + 2; /* +2 for space and null terminator */
                    new_value = (char far *)xfarmalloc(new_len);
                    if (new_value) {
                        if (old_value) {
                            _fstrcpy(new_value, old_value);
                            _fstrcat(new_value, " ");
                        } else {
                            new_value[0] = '\0';
                        }
                        _fstrcat(new_value, trimmed_line);
                        xfarfree(old_value);
                        res->value = new_value;
                        log_message("Appended machine config: %s", trimmed_line);
                    }
                }
            }
            continue;
        }

        /* Check if we're in a file list section */
        if (current_section_ptr && 
            (strcmp(current_section, "windows.system") == 0 ||
             strcmp(current_section, "windows") == 0 ||
             strcmp(current_section, "windows.system.386") == 0)) {
            
            /* Parse file list format with condition support */
            parse_file_list_line(trimmed_line, key_buf, value_buf, condition_buf, MAX_KEY_LENGTH);
            
            /* Skip if key is empty */
            if (strlen(key_buf) == 0) {
                continue;
            }
            
            /* Allocate more memory if needed */
            if (current_section_ptr->line_count >= current_section_ptr->lines_allocated) {
                new_alloc = current_section_ptr->lines_allocated == 0 ? 50 : current_section_ptr->lines_allocated * 2;
                if (new_alloc > MAX_LINES) {
                    new_alloc = MAX_LINES;
                }
                
                new_lines = (StringResource far *)xfarmalloc(new_alloc * sizeof(StringResource));
                if (!new_lines) {
                    continue; /* Out of memory */
                }
                
                if (current_section_ptr->lines) {
                    _fmemcpy(new_lines, current_section_ptr->lines, 
                            current_section_ptr->line_count * sizeof(StringResource));
                    xfarfree(current_section_ptr->lines);
                }
                
                current_section_ptr->lines = new_lines;
                current_section_ptr->lines_allocated = new_alloc;
            }
            
            if (current_section_ptr->line_count < current_section_ptr->lines_allocated) {
                /* Add the key-value pair with condition */
                res = &current_section_ptr->lines[current_section_ptr->line_count];
                res->key = far_strdup(key_buf);
                res->value = far_strdup(value_buf);
                res->condition = far_strdup(condition_buf);
                
                if (res->key && res->value) {
                    current_section_ptr->line_count++;
                } else {
                    /* Cleanup if allocation failed */
                    if (res->key) xfarfree(res->key);
                    if (res->value) xfarfree(res->value);
                    if (res->condition) xfarfree(res->condition);
                }
            }
            continue;
        }

        /* Process regular key-value pairs for other sections */
        if (current_section_ptr && (equal_sign = strchr(trimmed_line, '=')) != NULL) {
            *equal_sign = '\0';
            key_ptr = trimmed_line;
            value_ptr = equal_sign + 1;
            
            /* Trim whitespace from key */
            while (*key_ptr && isspace((unsigned char)*key_ptr)) key_ptr++;
            temp = key_ptr + strlen(key_ptr) - 1;
            while (temp > key_ptr && isspace((unsigned char)*temp)) {
                *temp = '\0';
                temp--;
            }
            
            /* Trim whitespace from value */
            while (*value_ptr && isspace((unsigned char)*value_ptr)) value_ptr++;
            temp = value_ptr + strlen(value_ptr) - 1;
            while (temp > value_ptr && isspace((unsigned char)*temp)) {
                *temp = '\0';
                temp--;
            }
            
            /* Remove quotes from value if present */
            if (value_ptr[0] == '"' && value_ptr[strlen(value_ptr)-1] == '"') {
                memmove(value_ptr, value_ptr+1, strlen(value_ptr)-2);
                value_ptr[strlen(value_ptr)-2] = '\0';
            }
            
            /* Skip if key is empty */
            if (strlen(key_ptr) == 0) {
                continue;
            }
            
            /* Allocate more memory if needed */
            if (current_section_ptr->line_count >= current_section_ptr->lines_allocated) {
                new_alloc = current_section_ptr->lines_allocated == 0 ? 50 : current_section_ptr->lines_allocated * 2;
                if (new_alloc > MAX_LINES) {
                    new_alloc = MAX_LINES;
                }
                
                new_lines = (StringResource far *)xfarmalloc(new_alloc * sizeof(StringResource));
                if (!new_lines) {
                    continue; /* Out of memory */
                }
                
                if (current_section_ptr->lines) {
                    _fmemcpy(new_lines, current_section_ptr->lines, 
                            current_section_ptr->line_count * sizeof(StringResource));
                    xfarfree(current_section_ptr->lines);
                }
                
                current_section_ptr->lines = new_lines;
                current_section_ptr->lines_allocated = new_alloc;
            }
            
            if (current_section_ptr->line_count < current_section_ptr->lines_allocated) {
                /* Add the key-value pair */
                res = &current_section_ptr->lines[current_section_ptr->line_count];
                res->key = far_strdup(key_ptr);
                res->value = far_strdup(value_ptr);
                res->condition = NULL;  /* No condition for regular key-value pairs */
                
                if (res->key && res->value) {
                    current_section_ptr->line_count++;
                } else {
                    /* Cleanup if allocation failed */
                    if (res->key) xfarfree(res->key);
                    if (res->value) xfarfree(res->value);
                }
            }
        }
    }
    
    fclose(file);
    log_message("Finished loading INF file. Total sections: %d", section_count);
    
    /* Debug: list all loaded sections */
    for (i = 0; i < section_count; i++) {
        log_message("Section [%s] has %d entries", sections[i].name, sections[i].line_count);
    }
}

char* get_string(const char* section, const char* key) {
    return get_string_default(section, key, NULL);
}

char* get_string_default(const char* section, const char* key, const char* default_value) {
    int i, j;
    StringResource far *res;
    char* result;
    unsigned int len;
    const char far *src;
    char *dst;
    
    for (i = 0; i < section_count; i++) {
        if (strcmp(sections[i].name, section) == 0) {
            for (j = 0; j < sections[i].line_count; j++) {
                res = &sections[i].lines[j];
                if (res->key && _fstrcmp(res->key, (const char far *)key) == 0) {
                    len = _fstrlen(res->value);
                    result = (char*)xmalloc(len + 1);
                    if (result) {
                        /* Copy from far to near memory */
                        src = res->value;
                        dst = result;
                        while (len--) {
                            *dst++ = *src++;
                        }
                        *dst = '\0';
                    }
                    return result;
                }
            }
            break;
        }
    }
    
    if (default_value) {
        result = (char*)xmalloc(strlen(default_value) + 1);
        if (result) {
            strcpy(result, default_value);
        }
        return result;
    }
    
    return NULL;
}

char* get_string_for_cpu(const char* base_section, const char* key, int cpu_type) {
    char section_name[100];
    char* result;
    
    if (cpu_type == CPU_386) {
        sprintf(section_name, "%s.win386", base_section);
        result = get_string(section_name, key);
        if (result) return result;
        
        sprintf(section_name, "%s.386", base_section);
        result = get_string(section_name, key);
        if (result) return result;
    } else if (cpu_type == CPU_286) {
        sprintf(section_name, "%s.286", base_section);
        result = get_string(section_name, key);
        if (result) return result;
    }
    
    return get_string(base_section, key);
}

int get_int(const char* section, const char* key, int default_value) {
    char* str_val;
    int result;
    
    str_val = get_string(section, key);
    if (str_val) {
        result = atoi(str_val);
        xfree(str_val);
        return result;
    }
    return default_value;
}

DiskInfo* get_disk_info(char disk) {
    int i;
    
    for (i = 0; i < disk_count; i++) {
        if (disk_info[i].disk == disk) {
            return &disk_info[i];
        }
    }
    
    return NULL;
}

char* get_disk_path(char disk) {
    DiskInfo* info;
    char* result;
    
    info = get_disk_info(disk);
    if (info && info->path[0]) {
        result = (char*)xmalloc(strlen(info->path) + 1);
        if (result) {
            strcpy(result, info->path);
        }
        return result;
    }
    return NULL;
}

char* get_disk_label(char disk) {
    DiskInfo* info;
    char* result;
    
    info = get_disk_info(disk);
    if (info && info->label[0]) {
        result = (char*)xmalloc(strlen(info->label) + 1);
        if (result) {
            strcpy(result, info->label);
        }
        return result;
    }
    return NULL;
}

char* get_disk_tag(char disk) {
    DiskInfo* info;
    char* result;
    
    info = get_disk_info(disk);
    if (info && info->tag[0]) {
        result = (char*)xmalloc(strlen(info->tag) + 1);
        if (result) {
            strcpy(result, info->tag);
        }
        return result;
    }
    return NULL;
}

char* get_current_language(void) {
    char* result;
    
    result = (char*)xmalloc(strlen(current_language) + 1);
    if (result) {
        strcpy(result, current_language);
    }
    return result;
}

InfSection* get_section(const char* section_name) {
    int i;
    
    for (i = 0; i < section_count; i++) {
        if (strcmp(sections[i].name, section_name) == 0) {
            return &sections[i];
        }
    }
    return NULL;
}

void free_resources(void) {
    int i, j;
    StringResource far *res;
    
    for (i = 0; i < section_count; i++) {
        if (sections[i].lines) {
            for (j = 0; j < sections[i].line_count; j++) {
                res = &sections[i].lines[j];
                if (res->key) xfarfree(res->key);
                if (res->value) xfarfree(res->value);
                if (res->condition) xfarfree(res->condition);
            }
            xfarfree(sections[i].lines);
            sections[i].lines = NULL;
        }
        sections[i].line_count = 0;
        sections[i].lines_allocated = 0;
    }
    section_count = 0;
    disk_count = 0;
}

int get_section_count(void) {
    return section_count;
}

char* get_private_profile_string(const char* section, const char* key, 
                                const char* default_val, const char* filename) {
    /* For now, use the already loaded INF file data */
    return get_string_default(section, key, default_val);
}

int get_private_profile_int(const char* section, const char* key, 
                           int default_val, const char* filename) {
    char* str_val;
    int result;
    
    str_val = get_private_profile_string(section, key, NULL, filename);
    if (str_val) {
        result = atoi(str_val);
        xfree(str_val);
        return result;
    }
    return default_val;
}
