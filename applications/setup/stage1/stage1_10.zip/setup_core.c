#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include <direct.h>
#include <fcntl.h>
#include <io.h>
#include <sys/stat.h>
#include <malloc.h>
#include <dos.h>
#include <stdarg.h>
#include <process.h>
#include "ui.h"
#include "setup_core.h"
#include "file_utils.h"
#include "resources.h"
#include "log.h"
#include "dialog.h"
#include "memory.h"

void setup_config_init(SetupConfig* config) {
    strcpy(config->windowsDir, "C:\\WINDOWS");
    strcpy(config->systemDir, "C:\\WINDOWS\\SYSTEM");
    strcpy(config->tempDir, "C:\\WINDOWS\\TEMP");
    strcpy(config->sourcePath, "");
    strcpy(config->logFile, "C:\\SETUP.LOG");
    config->cpu_type = 0; /* CPU_8086 */
    config->setupMode = 0;
    strcpy(config->inf_filename, "");
    strcpy(config->selected_network, "nonet");
    config->network_installed = 0;
    
    /* Initialize command line flags */
    config->ignore_autodetect = 0;
    config->network_setup = 0;
    config->admin_setup = 0;
    config->monochrome_setup = 0;
    config->scan_incompatible = 0;
    config->batch_file[0] = '\0';
    
    /* Initialize machine selection */
    config->selected_machine = -1;
    config->machine_name[0] = '\0';
}

int copy_file_with_version_check(const char *source, const char *dest, int setupMode) {
    /* If it's a new installation, always copy */
    if (setupMode == 0) {
        return copy_file(source, dest);
    }
    
    /* For upgrade mode, check if destination exists */
    if (!file_exists(dest)) {
        log_message("New file in upgrade: %s", dest);
        return copy_file(source, dest);
    }
    
    /* Check if source is newer than destination */
    if (is_source_file_newer(source, dest)) {
        log_message("Upgrading file (source is newer): %s", dest);
        return copy_file(source, dest);
    } else {
        log_message("Skipping file (destination is newer or same): %s", dest);
        return 1; /* Skip copying but return success */
    }
}

void update_autoexec_bat(const SetupConfig* config) {
    FILE *autoexec;
    char autoexec_path[80];
    char line[256];
    int path_updated = 0;
    int temp_updated = 0;
    int windir_updated = 0;
    
    /* Try multiple possible locations for AUTOEXEC.BAT */
    const char* possible_paths[] = {
        "C:\\AUTOEXEC.BAT",
        "A:\\AUTOEXEC.BAT", 
        "B:\\AUTOEXEC.BAT",
        NULL
    };
    
    int i;
    for (i = 0; possible_paths[i] != NULL; i++) {
        if (file_exists(possible_paths[i])) {
            strcpy(autoexec_path, possible_paths[i]);
            break;
        }
    }
    
    if (possible_paths[i] == NULL) {
        strcpy(autoexec_path, "C:\\AUTOEXEC.BAT");
    }
    
    /* First check if updates are already present */
    autoexec = fopen(autoexec_path, "rt");
    if (autoexec) {
        while (fgets(line, sizeof(line), autoexec)) {
            if (strstr(line, config->windowsDir)) path_updated = 1;
            if (strstr(line, "TEMP=") && strstr(line, config->tempDir)) temp_updated = 1;
            if (strstr(line, "WINDIR=") && strstr(line, config->windowsDir)) windir_updated = 1;
        }
        fclose(autoexec);
    }
    
    autoexec = fopen(autoexec_path, "at");
    if (autoexec) {
        log_message("Updating AUTOEXEC.BAT at %s", autoexec_path);
        
        if (!path_updated) {
            fprintf(autoexec, "\nSET PATH=%%PATH%%;%s;%s\n", config->windowsDir, config->systemDir);
        }
        if (!temp_updated) {
            fprintf(autoexec, "SET TEMP=%s\n", config->tempDir);
        }
        if (!windir_updated) {
            fprintf(autoexec, "SET WINDIR=%s\n", config->windowsDir);
        }
        
        fclose(autoexec);
    } else {
        log_message("Warning: Cannot open AUTOEXEC.BAT for update at %s", autoexec_path);
    }
}

void update_config_sys(void) {
    FILE *config;
    char config_path[80];
    char line[256];
    int files_updated = 0;
    int buffers_updated = 0;
    int stacks_updated = 0;
    
    /* Try multiple possible locations for CONFIG.SYS */
    const char* possible_paths[] = {
        "C:\\CONFIG.SYS",
        "A:\\CONFIG.SYS",
        "B:\\CONFIG.SYS",
        NULL
    };
    
    int i;
    for (i = 0; possible_paths[i] != NULL; i++) {
        if (file_exists(possible_paths[i])) {
            strcpy(config_path, possible_paths[i]);
            break;
        }
    }
    
    if (possible_paths[i] == NULL) {
        strcpy(config_path, "C:\\CONFIG.SYS");
    }
    
    /* First check if updates are already present */
    config = fopen(config_path, "rt");
    if (config) {
        while (fgets(line, sizeof(line), config)) {
            if (strstr(line, "FILES=")) files_updated = 1;
            if (strstr(line, "BUFFERS=")) buffers_updated = 1;
            if (strstr(line, "STACKS=")) stacks_updated = 1;
        }
        fclose(config);
    }
    
    config = fopen(config_path, "at");
    if (config) {
        log_message("Updating CONFIG.SYS at %s", config_path);
        
        if (!files_updated) {
            fprintf(config, "\nFILES=30\n");
        }
        if (!buffers_updated) {
            fprintf(config, "BUFFERS=20\n");
        }
        if (!stacks_updated) {
            fprintf(config, "STACKS=9,256\n");
        }
        
        fclose(config);
    } else {
        log_message("Warning: Cannot open CONFIG.SYS for update at %s", config_path);
    }
}

void setup_directories(const SetupConfig* config) {
    log_message("Creating directories: %s, %s", config->windowsDir, config->systemDir);
    create_directory(config->windowsDir);
    create_directory(config->systemDir);
    /* Don't create TEMP directory here - it will be created when needed */
}

void detect_setup_mode(SetupConfig* config) {
    char win_com_path[80];
    char win_ini_path[80];
    
    log_message("Checking setup mode for directory: %s", config->windowsDir);
    
    if (file_exists(config->windowsDir)) {
        /* Check for WIN.COM first */
        sprintf(win_com_path, "%s\\WIN.COM", config->windowsDir);
        if (file_exists(win_com_path)) {
            config->setupMode = 1; /* Upgrade mode */
            log_message("Setup mode: Upgrade (WIN.COM exists)");
            return;
        }
        
        /* Also check for WIN.INI as backup */
        sprintf(win_ini_path, "%s\\WIN.INI", config->windowsDir);
        if (file_exists(win_ini_path)) {
            config->setupMode = 1; /* Upgrade mode */
            log_message("Setup mode: Upgrade (WIN.INI exists)");
            return;
        }
        
        /* Directory exists but no Windows files found */
        config->setupMode = 0; /* New installation */
        log_message("Setup mode: New installation (Windows directory exists but no Windows files found)");
    } else {
        config->setupMode = 0; /* New installation */
        log_message("Setup mode: New installation (Windows directory doesn't exist)");
    }
}

void check_disk_space(const SetupConfig* config) {
    long requiredSpace = 0;
    long freeSpace = get_free_disk_space(config->windowsDir);
    char *minSpaceKey;
    char *minSpace;

    if (config->setupMode == 0) {
        switch (config->cpu_type) {
            case 2: /* CPU_386 */
                minSpaceKey = "neededspace386";
                break;
            case 1: /* CPU_286 */
                minSpaceKey = "neededspace286";
                break;
            case 0: /* CPU_8086 */
            default:
                minSpaceKey = "neededspace286";
                break;
        }
    } else {
        switch (config->cpu_type) {
            case 2: /* CPU_386 */
                requiredSpace = 3000000;
                break;
            case 1: /* CPU_286 */
                requiredSpace = 2000000;
                break;
            case 0: /* CPU_8086 */
            default:
                requiredSpace = 1500000;
                break;
        }
    }

    if (config->setupMode == 0) {
        minSpace = get_private_profile_string("data", minSpaceKey, NULL, config->inf_filename);
        if (minSpace) {
            requiredSpace = atol(minSpace);
            xfree(minSpace);
        } else {
            switch (config->cpu_type) {
                case 2: /* CPU_386 */
                    requiredSpace = 6300000;
                    break;
                case 1: /* CPU_286 */
                    requiredSpace = 4500000;
                    break;
                case 0: /* CPU_8086 */
                default:
                    requiredSpace = 4500000;
                    break;
            }
        }
    }

    log_message("Disk space check - Required: %ld, Available: %ld", requiredSpace, freeSpace);

    if (freeSpace < requiredSpace) {
        char message[100];
        sprintf(message, "Insufficient disk space. Required: %ld, Available: %ld", 
                requiredSpace, freeSpace);
        display_message(message);
        log_message("Fatal: %s", message);
        exit(1);
    }
}

void setup_configuration(const SetupConfig* config) {
    char wininiPath[80];
    char systeminiPath[80];
    FILE *winini, *systemini;
    
    /* Only create configuration files for new installations */
    if (config->setupMode == 1) {
        log_message("Skipping configuration file creation for upgrade mode");
        return;
    }
    
    sprintf(wininiPath, "%s\\WIN.INI", config->windowsDir);
    winini = fopen(wininiPath, "w");
    if (winini) {
        log_message("Creating WIN.INI");
        fprintf(winini, "[Windows]\n");
        fprintf(winini, "load=\n");
        fprintf(winini, "run=\n");
        fprintf(winini, "Beep=yes\n");
        fprintf(winini, "Spooler=yes\n");
        fprintf(winini, "NullPort=None\n");
        fprintf(winini, "BorderWidth=3\n");
        fprintf(winini, "CursorBlinkRate=530\n");
        fprintf(winini, "DoubleClickSpeed=452\n");
        fprintf(winini, "Programs=com exe bat pif\n");
        fprintf(winini, "Documents=\n");
        fprintf(winini, "DeviceNotSelectedTimeout=15\n");
        fprintf(winini, "TransmissionRetryTimeout=45\n");
        fclose(winini);
    } else {
        log_message("Error: Cannot create WIN.INI");
    }
    
    sprintf(systeminiPath, "%s\\SYSTEM.INI", config->windowsDir);
    systemini = fopen(systeminiPath, "w");
    if (systemini) {
        log_message("Creating SYSTEM.INI");
        fprintf(systemini, "[boot]\n");
        fprintf(systemini, "shell=progman.exe\n");
        
        switch (config->cpu_type) {
            case 2: /* CPU_386 */
                fprintf(systemini, "display.drv=vga.drv\n");
                fprintf(systemini, "keyboard.drv=keyboard.drv\n");
                fprintf(systemini, "mouse.drv=mouse.drv\n");
                fprintf(systemini, "fixedfon.fon=vgafix.fon\n");
                fprintf(systemini, "fonts.fon=vgasys.fon\n");
                fprintf(systemini, "oemfonts.fon=vgaoem.fon\n");
                break;
            case 1: /* CPU_286 */
                fprintf(systemini, "display.drv=vga.drv\n");
                fprintf(systemini, "keyboard.drv=keyboard.drv\n");
                fprintf(systemini, "mouse.drv=mouse.drv\n");
                fprintf(systemini, "fixedfon.fon=vgafix.fon\n");
                fprintf(systemini, "fonts.fon=vgasys.fon\n");
                fprintf(systemini, "oemfonts.fon=vgaoem.fon\n");
                break;
            case 0: /* CPU_8086 */
            default:
                fprintf(systemini, "display.drv=ega.drv\n");
                fprintf(systemini, "keyboard.drv=keyboard.drv\n");
                fprintf(systemini, "mouse.drv=mouse.drv\n");
                fprintf(systemini, "fixedfon.fon=egafix.fon\n");
                fprintf(systemini, "fonts.fon=egasys.fon\n");
                fprintf(systemini, "oemfonts.fon=egaoem.fon\n");
                break;
        }
        fclose(systemini);
    } else {
        log_message("Error: Cannot create SYSTEM.INI");
    }
}

void copy_setup_files(const SetupConfig* config) {
    char source_setup_exe[80];
    char dest_setup_exe[80];
    char dest_setup_inf[80];
    
    /* Copy SETUP.EXE from sourcePath to Windows directory */
    sprintf(source_setup_exe, "%s\\SETUP.EXE", config->sourcePath);
    sprintf(dest_setup_exe, "%s\\SETUP.EXE", config->windowsDir);
    
    /* Check if we're not trying to copy the file to the same location */
    if (strcmp(source_setup_exe, dest_setup_exe) != 0) {
        log_message("Copying SETUP.EXE: %s -> %s", source_setup_exe, dest_setup_exe);
        if (!copy_file_with_version_check(source_setup_exe, dest_setup_exe, config->setupMode)) {
            log_message("Warning: Failed to copy SETUP.EXE");
        }
    } else {
        log_message("Skipping SETUP.EXE copy (source and destination are the same)");
    }
    
    /* Copy the loaded INF file (from /o or default) to Windows\SYSTEM as SETUP.INF */
    sprintf(dest_setup_inf, "%s\\SYSTEM\\SETUP.INF", config->windowsDir);
    
    log_message("Copying INF file: %s -> %s", config->inf_filename, dest_setup_inf);
    if (!copy_file_with_version_check(config->inf_filename, dest_setup_inf, config->setupMode)) {
        log_message("Warning: Failed to copy INF file to %s", dest_setup_inf);
    }
}

int find_file_copy_section(FILE* file, const char* section_name) {
    char line[512];
    char current_section[100] = "";
    int in_target_section = 0;
    char* end;
    
    fseek(file, 0, SEEK_SET);
    
    while (fgets(line, sizeof(line), file) != NULL) {
        line[strcspn(line, "\r\n")] = 0;
        
        if (line[0] == '\0' || line[0] == ';') {
            continue;
        }
        
        if (line[0] == '[') {
            end = strchr(line, ']');
            if (end != NULL) {
                *end = '\0';
                strncpy(current_section, line + 1, sizeof(current_section)-1);
                current_section[sizeof(current_section)-1] = '\0';
                in_target_section = (strcmp(current_section, section_name) == 0);
            } else {
                in_target_section = 0;
            }
            continue;
        }
        
        if (in_target_section) {
            if (strchr(line, '=') != NULL) {
                return 1; /* Found files in this section */
            }
        }
    }
    
    return 0;
}

void remove_disk_prefix(char *str) {
    char *colon = strchr(str, ':');
    if (colon != NULL) {
        memmove(str, colon + 1, strlen(colon + 1) + 1);
    }
}

int should_copy_file(const char far *condition, const SetupConfig* config) {
    unsigned int cond_len;
    char *near_condition;
    int result;

    if (condition == NULL || condition[0] == '\0') {
        return 1; /* No condition - always copy */
    }
    
    /* Convert far condition to near string for comparison */
    cond_len = _fstrlen(condition);
    near_condition = (char*)xmalloc(cond_len + 1);
    if (near_condition) {
        _fstrcpy(near_condition, condition);
    } else {
        return 0; /* Out of memory - skip file */
    }
    
    result = 0;
    
    if (strcmp(near_condition, "Net") == 0) {
        /* Copy only for administrative setup */
        result = config->admin_setup;
        log_message("File condition 'Net': copying only for admin setup (admin_setup=%d)", config->admin_setup);
    } else {
        /* Copy if condition matches selected network */
        result = (strcmp(near_condition, config->selected_network) == 0);
        log_message("File condition '%s': copying only for network '%s' (selected_network=%s)", 
                   near_condition, near_condition, config->selected_network);
    }
    
    xfree(near_condition);
    return result;
}

void select_network(SetupConfig* config) {
    /* For now, default to nonet */
    /* In full implementation, this would show a network selection dialog */
    strcpy(config->selected_network, "nonet");
    config->network_installed = 0;
    log_message("Network selected: %s", config->selected_network);
}

void parse_line_with_condition(char *line, char **key, char **value, char **condition) {
    char *first_comma = strchr(line, ',');
    char *second_comma = NULL;
    char *val_end;
    char *key_end;
    
    *key = line;
    *value = line;  // default: value = key
    *condition = NULL;
    
    if (first_comma != NULL) {
        *first_comma = '\0';
        *value = first_comma + 1;
        
        second_comma = strchr(*value, ',');
        if (second_comma != NULL) {
            char *cond_end;

            *second_comma = '\0';
            *condition = second_comma + 1;
            
            // Trim condition
            while (**condition && isspace((unsigned char)**condition)) (*condition)++;
            cond_end = *condition + strlen(*condition) - 1;
            while (cond_end > *condition && isspace((unsigned char)*cond_end)) {
                *cond_end = '\0';
                cond_end--;
            }
        }
        
        // Trim value
        while (**value && isspace((unsigned char)**value)) (*value)++;
        val_end = *value + strlen(*value) - 1;
        while (val_end > *value && isspace((unsigned char)*val_end)) {
            *val_end = '\0';
            val_end--;
        }
    }
    
    // Trim key
    while (**key && isspace((unsigned char)**key)) (*key)++;
    key_end = *key + strlen(*key) - 1;
    while (key_end > *key && isspace((unsigned char)*key_end)) {
        *key_end = '\0';
        key_end--;
    }
}

/* New function to select machine type from [machine] section */
void select_machine_type(SetupConfig* config) {
    InfSection* machine_section;
    int i;
    char** menu_items;
    int item_count;
    int choice;
    StringResource far *res;
    unsigned int len;
    
    log_message("Selecting machine type");
    
    machine_section = get_section("machine");
    if (!machine_section || machine_section->line_count == 0) {
        log_message("No machine section found, using default");
        config->selected_machine = 0;
        strcpy(config->machine_name, "MS-DOS or PC-DOS System");
        return;
    }
    
    /* Count valid machine entries */
    item_count = 0;
    for (i = 0; i < machine_section->line_count; i++) {
        res = &machine_section->lines[i];
        if (res->key && _fstrlen(res->key) > 0) {
            item_count++;
        }
    }
    
    if (item_count == 0) {
        log_message("No machine entries found, using default");
        config->selected_machine = 0;
        strcpy(config->machine_name, "MS-DOS or PC-DOS System");
        return;
    }
    
    /* Create menu items */
    menu_items = (char**)xmalloc(item_count * sizeof(char*));
    if (!menu_items) {
        log_message("Memory allocation failed for machine menu");
        config->selected_machine = 0;
        strcpy(config->machine_name, "MS-DOS or PC-DOS System");
        return;
    }
    
    for (i = 0; i < item_count; i++) {
        res = &machine_section->lines[i];
        len = _fstrlen(res->key);
        menu_items[i] = (char*)xmalloc(len + 1);
        if (menu_items[i]) {
            _fstrcpy(menu_items[i], res->key);
        } else {
            menu_items[i] = "Unknown Machine";
        }
    }
    
    /* Display machine selection menu */
    display_header("Select Machine Type");
    choice = display_menu(10, 5, 60, item_count, "Select your computer type:", menu_items, item_count);
    
    /* Free menu items */
    for (i = 0; i < item_count; i++) {
        xfree(menu_items[i]);
    }
    xfree(menu_items);
    
    if (choice >= 0 && choice < item_count) {
        config->selected_machine = choice;
        res = &machine_section->lines[choice];
        len = _fstrlen(res->key);
        if (len < sizeof(config->machine_name)) {
            _fstrcpy(config->machine_name, res->key);
        }
        log_message("Selected machine: %s", config->machine_name);
    } else {
        /* Default selection */
        config->selected_machine = 0;
        strcpy(config->machine_name, "MS-DOS or PC-DOS System");
        log_message("Using default machine: %s", config->machine_name);
    }
}

/* FIXED: Improved function to copy machine-specific files */
void copy_machine_files(const SetupConfig* config) {
    InfSection* machine_section;
    InfSection* system_section;
    StringResource far *machine_res;
    char* machine_line;
    char* token;
    char* filename;
    char source_path[80];
    char dest_path[80];
    int i;
    
    if (config->selected_machine == -1) {
        log_message("No machine selected, skipping machine file copy");
        return;
    }
    
    log_message("Copying machine-specific files for: %s", config->machine_name);
    
    machine_section = get_section("machine");
    system_section = get_section("system");
    
    if (!machine_section || !system_section) {
        log_message("Machine or system section not found");
        return;
    }
    
    if (config->selected_machine >= machine_section->line_count) {
        log_message("Invalid machine selection");
        return;
    }
    
    machine_res = &machine_section->lines[config->selected_machine];
    if (!machine_res->value) {
        log_message("No machine configuration found");
        return;
    }
    
    /* Parse machine line to get driver names */
    machine_line = (char*)xmalloc(_fstrlen(machine_res->value) + 1);
    if (!machine_line) {
        log_message("Memory allocation failed for machine line");
        return;
    }
    _fstrcpy(machine_line, machine_res->value);
    
    /* Machine line contains driver names and parameters separated by spaces or commas */
    token = strtok(machine_line, " ,\t");
    while (token != NULL) {
        /* Skip parameters (those containing '=') and empty tokens */
        if (strchr(token, '=') == NULL && strlen(token) > 0) {
            /* Look up filename in system section */
            filename = get_string("system", token);
            if (filename) {
                log_message("Found filename for driver %s: %s", token, filename);
                remove_disk_prefix(filename);
                log_message("After removing disk prefix: %s", filename);
                
                sprintf(source_path, "%s\\%s", config->sourcePath, filename);
                sprintf(dest_path, "%s\\%s", config->systemDir, filename);
                
                log_message("Copying machine file: %s -> %s", source_path, dest_path);
                if (!copy_file_with_version_check(source_path, dest_path, config->setupMode)) {
                    log_message("Warning: Failed to copy machine file: %s", source_path);
                }
                
                xfree(filename);
            } else {
                log_message("Warning: No system file found for driver: %s", token);
            }
        }
        
        token = strtok(NULL, " ,\t");
    }
    
    xfree(machine_line);
}

int copy_files(const SetupConfig* config) {
    int i, j;
    char source_path[80], dest_path[80];
    InfSection* section_ptr;
    StringResource far *res;
    unsigned int key_len, value_len;
    char *near_key, *near_value;
    unsigned int cond_len;
    char *near_condition, *near_key_log;
    
    /* First, copy the critical setup files */
    copy_setup_files(config);
    
    /* Step 1: Copy windows.system files to SYSTEM directory with condition check */
    section_ptr = get_section("windows.system");
    if (section_ptr) {
        log_message("Copying files from [windows.system] section to SYSTEM directory");
        for (j = 0; j < section_ptr->line_count; j++) {
            res = &section_ptr->lines[j];
            if (res->key && res->value) {
                /* Check condition */
                if (!should_copy_file(res->condition, config)) {
                    /* Convert condition to near string for logging */
                    if (res->condition && _fstrlen(res->condition) > 0) {
                        cond_len = _fstrlen(res->condition);
                        near_condition = (char*)xmalloc(cond_len + 1);
                        if (near_condition) {
                            _fstrcpy(near_condition, res->condition);
                            
                            key_len = _fstrlen(res->key);
                            near_key_log = (char*)xmalloc(key_len + 1);
                            if (near_key_log) {
                                _fstrcpy(near_key_log, res->key);
                                
                                log_message("Skipping file due to condition '%s': %s", near_condition, near_key_log);
                                xfree(near_key_log);
                            }
                            xfree(near_condition);
                        }
                    }
                    continue; /* Skip file due to condition */
                }
                
                /* Convert far strings to near for sprintf */
                key_len = _fstrlen(res->key);
                value_len = _fstrlen(res->value);
                near_key = (char*)xmalloc(key_len + 1);
                near_value = (char*)xmalloc(value_len + 1);
                
                if (near_key && near_value) {
                    _fstrcpy(near_key, res->key);
                    _fstrcpy(near_value, res->value);
                    
                    sprintf(source_path, "%s\\%s", config->sourcePath, near_key);
                    sprintf(dest_path, "%s\\%s", config->systemDir, near_value);
                    
                    if (!copy_file_with_version_check(source_path, dest_path, config->setupMode)) {
                        log_message("Warning: Failed to copy system file: %s", source_path);
                    }
                    
                    xfree(near_key);
                    xfree(near_value);
                } else {
                    /* Free allocated memory if one of them failed */
                    if (near_key) xfree(near_key);
                    if (near_value) xfree(near_value);
                }
            }
        }
    } else {
        log_message("Warning: [windows.system] section not found in INF file");
    }
    
    /* Step 2: Copy windows files to WINDOWS directory with condition check */
    section_ptr = get_section("windows");
    if (section_ptr) {
        log_message("Copying files from [windows] section to WINDOWS directory");
        for (j = 0; j < section_ptr->line_count; j++) {
            res = &section_ptr->lines[j];
            if (res->key && res->value) {
                /* Check condition */
                if (!should_copy_file(res->condition, config)) {
                    /* Convert condition to near string for logging */
                    if (res->condition && _fstrlen(res->condition) > 0) {
                        cond_len = _fstrlen(res->condition);
                        near_condition = (char*)xmalloc(cond_len + 1);
                        if (near_condition) {
                            _fstrcpy(near_condition, res->condition);
                            
                            key_len = _fstrlen(res->key);
                            near_key_log = (char*)xmalloc(key_len + 1);
                            if (near_key_log) {
                                _fstrcpy(near_key_log, res->key);
                                
                                log_message("Skipping file due to condition '%s': %s", near_condition, near_key_log);
                                xfree(near_key_log);
                            }
                            xfree(near_condition);
                        }
                    }
                    continue; /* Skip file due to condition */
                }
                
                /* Convert far strings to near for sprintf */
                key_len = _fstrlen(res->key);
                value_len = _fstrlen(res->value);
                near_key = (char*)xmalloc(key_len + 1);
                near_value = (char*)xmalloc(value_len + 1);
                
                if (near_key && near_value) {
                    _fstrcpy(near_key, res->key);
                    _fstrcpy(near_value, res->value);
                    
                    sprintf(source_path, "%s\\%s", config->sourcePath, near_key);
                    sprintf(dest_path, "%s\\%s", config->windowsDir, near_value);
                    
                    if (!copy_file_with_version_check(source_path, dest_path, config->setupMode)) {
                        log_message("Warning: Failed to copy windows file: %s", source_path);
                    }
                    
                    xfree(near_key);
                    xfree(near_value);
                } else {
                    /* Free allocated memory if one of them failed */
                    if (near_key) xfree(near_key);
                    if (near_value) xfree(near_value);
                }
            }
        }
    } else {
        log_message("Warning: [windows] section not found in INF file");
    }
    
    /* Step 3: Copy CPU-specific sections for 386 with condition check */
    if (config->cpu_type == 2) { /* CPU_386 */
        section_ptr = get_section("windows.system.386");
        if (section_ptr) {
            log_message("Copying files from [windows.system.386] section to SYSTEM directory");
            for (j = 0; j < section_ptr->line_count; j++) {
                res = &section_ptr->lines[j];
                if (res->key && res->value) {
                    /* Check condition */
                    if (!should_copy_file(res->condition, config)) {
                        /* Convert condition to near string for logging */
                        if (res->condition && _fstrlen(res->condition) > 0) {
                            cond_len = _fstrlen(res->condition);
                            near_condition = (char*)xmalloc(cond_len + 1);
                            if (near_condition) {
                                _fstrcpy(near_condition, res->condition);
                                
                                key_len = _fstrlen(res->key);
                                near_key_log = (char*)xmalloc(key_len + 1);
                                if (near_key_log) {
                                    _fstrcpy(near_key_log, res->key);
                                    
                                    log_message("Skipping file due to condition '%s': %s", near_condition, near_key_log);
                                    xfree(near_key_log);
                                }
                                xfree(near_condition);
                            }
                        }
                        continue; /* Skip file due to condition */
                    }
                    
                    /* Convert far strings to near for sprintf */
                    key_len = _fstrlen(res->key);
                    value_len = _fstrlen(res->value);
                    near_key = (char*)xmalloc(key_len + 1);
                    near_value = (char*)xmalloc(value_len + 1);
                    
                    if (near_key && near_value) {
                        _fstrcpy(near_key, res->key);
                        _fstrcpy(near_value, res->value);
                        
                        sprintf(source_path, "%s\\%s", config->sourcePath, near_key);
                        sprintf(dest_path, "%s\\%s", config->systemDir, near_value);
                        
                        if (!copy_file_with_version_check(source_path, dest_path, config->setupMode)) {
                            log_message("Warning: Failed to copy 386 system file: %s", source_path);
                        }
                        
                        xfree(near_key);
                        xfree(near_value);
                    } else {
                        /* Free allocated memory if one of them failed */
                        if (near_key) xfree(near_key);
                        if (near_value) xfree(near_value);
                    }
                }
            }
        }
    }
    
    /* Step 4: Copy machine-specific files */
    if (config->selected_machine == -1) {
        select_machine_type((SetupConfig*)config);
    }
    copy_machine_files(config);
    
    log_message("File copy completed from windows and windows.system sections");
    return 1;
}

int launch_stage2(const SetupConfig* config) {
    char win_com_path[80];
    char command[512];
    
    /* Only try to launch Windows, not setup again */
    sprintf(win_com_path, "%s\\WIN.COM", config->windowsDir);
    
    if (file_exists(win_com_path)) {
        log_message("Launching Windows: %s", win_com_path);
        printf("\nSetup completed successfully. Launching Windows...\n");
        
        /* Use system call instead of spawn to avoid memory issues */
        sprintf(command, "%s", win_com_path);
        return system(command);
    }
    
    /* If WIN.COM not found, just exit successfully */
    log_message("Windows setup completed. WIN.COM not found, exiting.");
    printf("\nWindows setup completed successfully.\n");
    printf("You can now run Windows by typing WIN at the command prompt.\n");
    return 0;
}

void display_command_line_help(void) {
    printf("Windows Setup Command Line Switches:\n\n");
    printf("/?      Display this help message\n");
    printf("/i      Ignore automatic hardware detection\n");
    printf("/n      Set up a shared copy of Windows from a network server\n");
    printf("/a      Administrative Setup: copy all files to network server and mark as read-only\n");
    printf("/b      Set up Windows with monochrome display attributes\n");
    printf("/t      Search for incompatible software (for maintenance only)\n");
    printf("/h:filename Run Batch Mode Setup using the specified system settings file\n");
    printf("/o:filename Specify the SETUP.INF file\n");
    printf("/s:filename Specify the path for Windows installation disks\n\n");
}

void parse_command_line(int argc, char *argv[], SetupConfig* config) {
    int i;
    
    for (i = 1; i < argc; i++) {
        if (argv[i][0] == '/' || argv[i][0] == '-') {
            if (strlen(argv[i]) < 2) {
                log_message("Warning: Invalid command line switch: %s", argv[i]);
                continue;
            }
            
            switch (tolower(argv[i][1])) {
                case '?':
                    display_command_line_help();
                    exit(0);
                    break;
                    
                case 'i':
                    config->ignore_autodetect = 1;
                    log_message("Command line: /i - Ignore automatic hardware detection");
                    break;
                    
                case 'n':
                    config->network_setup = 1;
                    log_message("Command line: /n - Network setup");
                    break;
                    
                case 'a':
                    config->admin_setup = 1;
                    log_message("Command line: /a - Administrative setup");
                    break;
                    
                case 'b':
                    config->monochrome_setup = 1;
                    log_message("Command line: /b - Monochrome display");
                    break;
                    
                case 't':
                    config->scan_incompatible = 1;
                    log_message("Command line: /t - Scan for incompatible software");
                    break;
                    
                case 'h':
                    if (strlen(argv[i]) > 3 && argv[i][2] == ':') {
                        strncpy(config->batch_file, argv[i] + 3, 80 - 1);
                        config->batch_file[80-1] = '\0';
                        log_message("Command line: /h:%s - Batch mode setup", config->batch_file);
                    } else {
                        log_message("Warning: Invalid /h switch format: %s", argv[i]);
                    }
                    break;
                    
                case 'o':
                    if (strlen(argv[i]) > 3 && argv[i][2] == ':') {
                        strncpy(config->inf_filename, argv[i] + 3, 260 - 1);
                        config->inf_filename[260-1] = '\0';
                        log_message("Command line: /o:%s - Custom INF file", config->inf_filename);
                    } else {
                        log_message("Warning: Invalid /o switch format: %s", argv[i]);
                    }
                    break;
                    
                case 's':
                    if (strlen(argv[i]) > 3 && argv[i][2] == ':') {
                        strncpy(config->sourcePath, argv[i] + 3, 80 - 1);
                        config->sourcePath[80-1] = '\0';
                        log_message("Command line: /s:%s - Custom source path", config->sourcePath);
                    } else {
                        log_message("Warning: Invalid /s switch format: %s", argv[i]);
                    }
                    break;
                    
                default:
                    log_message("Warning: Unknown command line switch: %s", argv[i]);
                    break;
            }
        } else {
            /* ���� �������� ��� �����, ������� ��� ����� � �������� ������ */
            if (config->sourcePath[0] == '\0') {
                strncpy(config->sourcePath, argv[i], 80 - 1);
                config->sourcePath[80-1] = '\0';
                log_message("Command line: source path = %s", config->sourcePath);
            }
        }
    }
}
