#ifndef HELP_H
#define HELP_H

void display_help_screens(const char* topic);

#endif
