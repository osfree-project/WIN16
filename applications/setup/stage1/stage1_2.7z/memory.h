#ifndef MEMORY_H
#define MEMORY_H

#include <stdlib.h>

/* Far memory functions */
void far * far xfarmalloc(unsigned long size);
void far xfarfree(void far *ptr);

/* Near memory functions */
void* xmalloc(size_t size);
void xfree(void *ptr);
char* xstrdup(const char *str);

#endif
