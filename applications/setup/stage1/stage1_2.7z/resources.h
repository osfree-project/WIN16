#ifndef RESOURCES_H
#define RESOURCES_H

#include <stdio.h>
#include <stdarg.h>
#include "memory.h"

#define MAX_STRINGS 500
#define MAX_KEY_LENGTH 50
#define MAX_VALUE_LENGTH 300
#define MAX_SECTION_LENGTH 50
#define MAX_LANGUAGE_LENGTH 10
#define MAX_DISKS 20
#define MAX_SECTIONS 50
#define MAX_LINES 2000

/* CPU type constants */
#define CPU_8086 0
#define CPU_286  1
#define CPU_386  2

typedef struct {
    char far *key;
    char far *value;
} StringResource;

typedef struct {
    char disk;
    char path[MAX_VALUE_LENGTH];
    char label[MAX_VALUE_LENGTH];
    char tag[MAX_VALUE_LENGTH];
} DiskInfo;

struct InfSection {
    char name[MAX_SECTION_LENGTH];
    StringResource far *lines;
    int line_count;
    int lines_allocated;
};

typedef struct InfSection InfSection;

void load_inf_file(const char* filename);
char* get_string(const char* section, const char* key);
char* get_string_default(const char* section, const char* key, const char* default_value);
char* get_string_for_cpu(const char* base_section, const char* key, int cpu_type);
int get_int(const char* section, const char* key, int default_value);
DiskInfo* get_disk_info(char disk);
char* get_disk_path(char disk);
char* get_disk_label(char disk);
char* get_disk_tag(char disk);
char* get_current_language(void);
InfSection* get_section(const char* section_name);
void free_resources(void);
int get_section_count(void);

/* New functions for direct INF file access */
char* get_private_profile_string(const char* section, const char* key, const char* default_val, const char* filename);
int get_private_profile_int(const char* section, const char* key, int default_val, const char* filename);

#endif
