#ifndef INF_PARSER_H
#define INF_PARSER_H

#include "resources.h"


/* Helper functions */
void remove_disk_prefix(char *filename);

#endif
