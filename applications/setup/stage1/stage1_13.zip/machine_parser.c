#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "resources.h"
#include "memory.h"
#include "log.h"
#include "machine_parser.h"

/* FIXED: ����������� ������ ��� machine entries (��� � ���������) */
static MachineEntry machine_entries[50]; /* MAX_SECTIONS */
static int machine_entry_count = 0;

/* FIXED: Helper function to parse machine section lines */
static void parse_machine_section_line(const char* line, char** description, char** config)
{
    static char current_description[512] = "";
    static char current_config[2048] = "";
    static int in_machine_entry = 0;
    
    char line_copy[512];
    char *temp;
    char *end_ptr;
    char *first_quote;
    char *second_quote;
    char *third_quote;
    char *fourth_quote;
    char *config_start;
    char *comment_pos;
    int desc_len;
    
    *description = NULL;
    *config = NULL;
    
    if (!line || strlen(line) == 0) return;
    
    strncpy(line_copy, line, sizeof(line_copy) - 1);
    line_copy[sizeof(line_copy) - 1] = '\0';
    
    temp = line_copy;
    while (*temp && isspace((unsigned char)*temp)) temp++;
    end_ptr = line_copy + strlen(line_copy) - 1;
    while (end_ptr > line_copy && isspace((unsigned char)*end_ptr)) {
        *end_ptr = '\0';
        end_ptr--;
    }
    
    if (strlen(line_copy) == 0 || line_copy[0] == ';') {
        return;
    }
    
    if (line_copy[0] == '"') {
        if (in_machine_entry && strlen(current_description) > 0) {
            *description = (char*)xmalloc(strlen(current_description) + 1);
            *config = (char*)xmalloc(strlen(current_config) + 1);
            if (*description && *config) {
                strcpy(*description, current_description);
                strcpy(*config, current_config);
            }
        }
        
        current_description[0] = '\0';
        current_config[0] = '\0';
        in_machine_entry = 1;
        
        first_quote = line_copy;
        second_quote = strchr(first_quote + 1, '"');
        
        if (second_quote != NULL) {
            desc_len = second_quote - (first_quote + 1);
            if (desc_len > 0 && desc_len < (int)sizeof(current_description)) {
                strncpy(current_description, first_quote + 1, desc_len);
                current_description[desc_len] = '\0';
                
                third_quote = strchr(second_quote + 1, '"');
                if (third_quote != NULL) {
                    fourth_quote = strchr(third_quote + 1, '"');
                    if (fourth_quote != NULL) {
                        /* We have machine ID between third and fourth quotes */
                        config_start = fourth_quote + 1;
                    } else {
                        config_start = third_quote + 1;
                    }
                } else {
                    config_start = second_quote + 1;
                }
                
                while (*config_start && isspace((unsigned char)*config_start)) config_start++;
                
                comment_pos = strchr(config_start, ';');
                if (comment_pos != NULL) {
                    *comment_pos = '\0';
                }
                
                end_ptr = config_start + strlen(config_start) - 1;
                while (end_ptr > config_start && isspace((unsigned char)*end_ptr)) {
                    *end_ptr = '\0';
                    end_ptr--;
                }
                
                if (strlen(config_start) > 0) {
                    strcpy(current_config, config_start);
                }
            }
        }
    } else {
        if (in_machine_entry) {
            char config_line[512];
            char *comment_pos;

            strncpy(config_line, line_copy, sizeof(config_line) - 1);
            config_line[sizeof(config_line) - 1] = '\0';
            
            comment_pos = strchr(config_line, ';');
            if (comment_pos != NULL) {
                *comment_pos = '\0';
            }
            
            temp = config_line;
            while (*temp && isspace((unsigned char)*temp)) temp++;
            end_ptr = config_line + strlen(config_line) - 1;
            while (end_ptr > config_line && isspace((unsigned char)*end_ptr)) {
                *end_ptr = '\0';
                end_ptr--;
            }
            
            if (strlen(config_line) > 0) {
                if (strlen(current_config) > 0) {
                    strcat(current_config, " ");
                }
                strcat(current_config, config_line);
            }
        }
    }
}

void parse_machine_configuration(const char far *config_str, MachineEntry* entry, const char far *description)
{
    char* config_copy;
    char* token;
    int field_index;
    int i;
    unsigned int len;
    const char far *p;
    const char far *src;
    char *dst;
    
    config_copy = NULL;
    token = NULL;
    field_index = 0;
    
    entry->description = NULL;
    entry->machine_id = NULL;
    entry->system_drv = NULL;
    entry->kbd_drv = NULL;
    entry->kbd_type = NULL;
    entry->mouse_drv = NULL;
    entry->disp_drv = NULL;
    entry->sound_drv = NULL;
    entry->comm_drv = NULL;
    entry->himem_switch = NULL;
    entry->ebios = NULL;
    entry->cookie_count = 0;
    for (i = 0; i < 10; i++) {
        entry->cookies[i] = NULL;
    }
    
    if (description) {
        len = _fstrlen(description);
        entry->description = (char far*)xfarmalloc(len + 1);
        if (entry->description) _fstrcpy(entry->description, description);
    }
    
    if (!config_str) {
        return;
    }
    
    len = 0;
    p = config_str;
    while (*p) {
        len++;
        p++;
    }
    
    config_copy = (char*)xmalloc(len + 1);
    if (!config_copy) {
        return;
    }
    
    src = config_str;
    dst = config_copy;
    for (i = 0; i < len; i++) {
        *dst++ = *src++;
    }
    *dst = '\0';
    
    token = strtok(config_copy, " \t");
    while (token != NULL) {
        if (strlen(token) == 0) {
            token = strtok(NULL, " \t");
            continue;
        }
        
        switch (field_index) {
            case 0:
                if (strcmp(token, "system") == 0) {
                    entry->system_drv = (char far*)xfarmalloc(strlen("system.drv") + 1);
                    if (entry->system_drv) _fstrcpy(entry->system_drv, "system.drv");
                } else {
                    entry->system_drv = (char far*)xfarmalloc(strlen(token) + 1);
                    if (entry->system_drv) _fstrcpy(entry->system_drv, token);
                }
                break;
            case 1:
                entry->kbd_drv = (char far*)xfarmalloc(strlen(token) + 1);
                if (entry->kbd_drv) _fstrcpy(entry->kbd_drv, token);
                break;
            case 2:
                entry->kbd_type = (char far*)xfarmalloc(strlen(token) + 1);
                if (entry->kbd_type) _fstrcpy(entry->kbd_type, token);
                break;
            case 3:
                entry->mouse_drv = (char far*)xfarmalloc(strlen(token) + 1);
                if (entry->mouse_drv) _fstrcpy(entry->mouse_drv, token);
                break;
            case 4:
                entry->disp_drv = (char far*)xfarmalloc(strlen(token) + 1);
                if (entry->disp_drv) _fstrcpy(entry->disp_drv, token);
                break;
            case 5:
                entry->sound_drv = (char far*)xfarmalloc(strlen(token) + 1);
                if (entry->sound_drv) _fstrcpy(entry->sound_drv, token);
                break;
            case 6:
                entry->comm_drv = (char far*)xfarmalloc(strlen(token) + 1);
                if (entry->comm_drv) _fstrcpy(entry->comm_drv, token);
                break;
            case 7:
                entry->himem_switch = (char far*)xfarmalloc(strlen(token) + 1);
                if (entry->himem_switch) _fstrcpy(entry->himem_switch, token);
                break;
            case 8:
                entry->ebios = (char far*)xfarmalloc(strlen(token) + 1);
                if (entry->ebios) _fstrcpy(entry->ebios, token);
                break;
            default:
                if (entry->cookie_count < 10) {
                    entry->cookies[entry->cookie_count] = (char far*)xfarmalloc(strlen(token) + 1);
                    if (entry->cookies[entry->cookie_count]) _fstrcpy(entry->cookies[entry->cookie_count], token);
                    entry->cookie_count++;
                }
                break;
        }
        
        field_index++;
        token = strtok(NULL, " \t");
    }
    
    xfree(config_copy);
}

/* FIXED: Use new interface for section access */
void parse_all_machine_entries(void) {
    char far * far *lines;
    int line_count;
    int i;
    int entry_index;
    char current_description[512];
    char current_config[2048];
    int in_machine_entry;
    char *line_key;
    char *line_value;
    char *line_condition;
    char line_copy[512];
    
    for (i = 0; i < machine_entry_count; i++) {
        free_machine_entry(&machine_entries[i]);
    }
    machine_entry_count = 0;
    
    if (!get_section_lines("machine", &lines, &line_count)) {
        log_message("No machine section found for parsing");
        return;
    }
    
    /* FIXED: Parse machine section from raw lines on demand */
    entry_index = 0;
    current_description[0] = '\0';
    current_config[0] = '\0';
    in_machine_entry = 0;
    
    for (i = 0; i < line_count && entry_index < 50; i++) {
        if (!lines[i]) continue;
        
        line_key = NULL;
        line_value = NULL;
        line_condition = NULL;
        
        _fstrncpy(line_copy, lines[i], sizeof(line_copy) - 1);
        line_copy[sizeof(line_copy) - 1] = '\0';
        
        parse_machine_section_line(line_copy, &line_key, &line_value);
        
        if (line_key && line_value) {
            /* We found a complete machine entry */
            parse_machine_configuration((const char far*)line_value, &machine_entries[entry_index], (const char far*)line_key);
            entry_index++;
            
            if (line_key) xfree(line_key);
            if (line_value) xfree(line_value);
        }
    }
    
    _ffree(lines);
    
    machine_entry_count = entry_index;
    
    log_message("Parsing %d machine entries", machine_entry_count);
    
    for (i = 0; i < machine_entry_count; i++) {
        log_message("Machine %d: %s -> system_drv=%s", i, 
                   machine_entries[i].description ? machine_entries[i].description : "NULL", 
                   machine_entries[i].system_drv ? machine_entries[i].system_drv : "NULL");
    }
    
    log_message("Successfully parsed %d machine entries", machine_entry_count);
}

MachineEntry* get_machine_entry(int index)
{
    if (index >= 0 && index < machine_entry_count) {
        return &machine_entries[index];
    }
    return NULL;
}

int get_machine_entry_count(void)
{
    return machine_entry_count;
}

void free_machine_entry(MachineEntry* entry)
{
    int i;
    
    if (!entry) return;
    
    if (entry->description) xfarfree(entry->description);
    if (entry->machine_id) xfarfree(entry->machine_id);
    if (entry->system_drv) xfarfree(entry->system_drv);
    if (entry->kbd_drv) xfarfree(entry->kbd_drv);
    if (entry->kbd_type) xfarfree(entry->kbd_type);
    if (entry->mouse_drv) xfarfree(entry->mouse_drv);
    if (entry->disp_drv) xfarfree(entry->disp_drv);
    if (entry->sound_drv) xfarfree(entry->sound_drv);
    if (entry->comm_drv) xfarfree(entry->comm_drv);
    if (entry->himem_switch) xfarfree(entry->himem_switch);
    if (entry->ebios) xfarfree(entry->ebios);
    
    for (i = 0; i < entry->cookie_count; i++) {
        if (entry->cookies[i]) xfarfree(entry->cookies[i]);
    }
    
    entry->cookie_count = 0;
}

void free_all_machine_entries(void)
{
    int i;
    for (i = 0; i < machine_entry_count; i++) {
        free_machine_entry(&machine_entries[i]);
    }
    machine_entry_count = 0;
}
