#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdarg.h>
#include <malloc.h>
#include "resources.h"
#include "log.h"

static char inf_filename[260] = "";
static DiskInfo disks[MAX_DISKS];
static int disk_count = 0;
static char current_language[MAX_LANGUAGE_LENGTH] = "usa";

static void trim(char *str)
{
    int i;
    int len;
    int start;
    
    if (str == NULL) return;
    
    len = strlen(str);
    if (len == 0) return;
    
    i = len - 1;
    while (i >= 0 && isspace((unsigned char)str[i])) {
        str[i] = '\0';
        i--;
    }
    
    start = 0;
    while (isspace((unsigned char)str[start])) {
        start++;
    }
    
    if (start > 0) {
        memmove(str, str + start, strlen(str) - start + 1);
    }
}

static void remove_quotes(char *str)
{
    int len;
    
    if (str == NULL) return;
    
    len = strlen(str);
    if (len > 0 && str[0] == '"') {
        memmove(str, str + 1, len);
        len--;
        if (len > 0 && str[len-1] == '"') {
            str[len-1] = '\0';
        }
    }
}

char* get_private_profile_string(const char* section, const char* key, const char* default_val, const char* filename)
{
    FILE* file;
    char line[512];
    char current_section[100] = "";
    char* equal_ptr;
    char* key_ptr;
    char* value_ptr;
    char* result = NULL;
    int in_target_section = 0;
    char* end;
    
    if (filename == NULL || section == NULL || key == NULL) {
        if (default_val != NULL) {
            return strdup(default_val);
        }
        return NULL;
    }
    
    file = fopen(filename, "rt");
    if (file == NULL) {
        log_message("Error: Cannot open INF file %s", filename);
        if (default_val != NULL) {
            return strdup(default_val);
        }
        return NULL;
    }
    
    while (fgets(line, sizeof(line), file) != NULL) {
        line[strcspn(line, "\r\n")] = 0;
        
        /* Skip empty lines and comments */
        if (line[0] == '\0' || line[0] == ';') {
            continue;
        }
        
        /* Handle section headers */
        if (line[0] == '[') {
            end = strchr(line, ']');
            if (end != NULL) {
                *end = '\0';
                strncpy(current_section, line + 1, sizeof(current_section)-1);
                current_section[sizeof(current_section)-1] = '\0';
                trim(current_section);
                
                in_target_section = (strcmp(current_section, section) == 0);
            }
            continue;
        }
        
        /* If we're in the target section, look for the key */
        if (in_target_section) {
            equal_ptr = strchr(line, '=');
            if (equal_ptr != NULL) {
                *equal_ptr = '\0';
                key_ptr = line;
                value_ptr = equal_ptr + 1;
                
                trim(key_ptr);
                trim(value_ptr);
                remove_quotes(value_ptr);
                
                if (strcmp(key_ptr, key) == 0) {
                    result = strdup(value_ptr);
                    break;
                }
            }
        }
    }
    
    fclose(file);
    
    if (result != NULL) {
        log_message("Found %s.%s = %s", section, key, result);
        return result;
    } else {
        log_message("Using default for %s.%s = %s", section, key, default_val ? default_val : "(null)");
        if (default_val != NULL) {
            return strdup(default_val);
        }
        return NULL;
    }
}

int get_private_profile_int(const char* section, const char* key, int default_val, const char* filename)
{
    char* value = get_private_profile_string(section, key, NULL, filename);
    if (value != NULL) {
        int result = atoi(value);
        free(value);
        return result;
    }
    return default_val;
}

/* Legacy functions that use the new implementation */
void load_inf_file(const char* filename)
{
    if (filename == NULL || strlen(filename) == 0) {
        log_message("Error: INF filename is NULL or empty");
        return;
    }

    strncpy(inf_filename, filename, sizeof(inf_filename)-1);
    inf_filename[sizeof(inf_filename)-1] = '\0';
    
    log_message("INF file set to: %s", filename);
}

char* get_string(const char* section, const char* key)
{
    return get_private_profile_string(section, key, NULL, inf_filename);
}

char* get_string_default(const char* section, const char* key, const char* default_value)
{
    char* result = get_private_profile_string(section, key, default_value, inf_filename);
    return result;
}

char* get_string_for_cpu(const char* base_section, const char* key, int cpu_type)
{
    char section_name[50];
    char* result = NULL;
    
    switch (cpu_type) {
        case 2:
            sprintf(section_name, "%s.386", base_section);
            result = get_string(section_name, key);
            if (result != NULL) return result;
            break;
        case 1:
            sprintf(section_name, "%s.286", base_section);
            result = get_string(section_name, key);
            if (result != NULL) return result;
            break;
        case 0:
        default:
            sprintf(section_name, "%s.86", base_section);
            result = get_string(section_name, key);
            if (result != NULL) return result;
            break;
    }
    
    return get_string(base_section, key);
}

int get_int(const char* section, const char* key, int default_value)
{
    return get_private_profile_int(section, key, default_value, inf_filename);
}

static void ensure_disks_loaded(void)
{
    FILE* file;
    char line[512];
    char* first_comma;
    char* second_comma;
    char* path;
    char* label;
    char* tag;
    char value_copy[MAX_VALUE_LENGTH];
    char* value_ptr;
    int in_disks_section = 0;
    char* equal_ptr;
    char* key_ptr;

    if (disk_count > 0) return;
    
    file = fopen(inf_filename, "rt");
    if (file == NULL) {
        return;
    }
    
    while (fgets(line, sizeof(line), file) != NULL && disk_count < MAX_DISKS) {
        line[strcspn(line, "\r\n")] = 0;
        
        if (line[0] == '\0' || line[0] == ';') {
            continue;
        }
        
        if (line[0] == '[') {
            char* end = strchr(line, ']');
            if (end != NULL) {
                *end = '\0';
                in_disks_section = (strcmp(line + 1, "disks") == 0);
            }
            continue;
        }
        
        if (in_disks_section) {
            equal_ptr = strchr(line, '=');
            if (equal_ptr != NULL) {
                *equal_ptr = '\0';
                key_ptr = line;
                value_ptr = equal_ptr + 1;
                
                trim(key_ptr);
                strncpy(value_copy, value_ptr, sizeof(value_copy)-1);
                value_copy[sizeof(value_copy)-1] = '\0';
                trim(value_copy);
                
                first_comma = strchr(value_copy, ',');
                if (first_comma != NULL) {
                    *first_comma = '\0';
                    path = value_copy;
                    
                    second_comma = strchr(first_comma + 1, ',');
                    if (second_comma != NULL) {
                        *second_comma = '\0';
                        label = first_comma + 1;
                        tag = second_comma + 1;
                        
                        trim(path);
                        trim(label);
                        trim(tag);
                        remove_quotes(label);
                        
                        if (strcmp(path, "=.") == 0) {
                            strcpy(disks[disk_count].path, ".");
                        } else {
                            strncpy(disks[disk_count].path, path, sizeof(disks[disk_count].path)-1);
                            disks[disk_count].path[sizeof(disks[disk_count].path)-1] = '\0';
                        }
                        
                        disks[disk_count].disk = key_ptr[0];
                        strncpy(disks[disk_count].label, label, sizeof(disks[disk_count].label)-1);
                        disks[disk_count].label[sizeof(disks[disk_count].label)-1] = '\0';
                        strncpy(disks[disk_count].tag, tag, sizeof(disks[disk_count].tag)-1);
                        disks[disk_count].tag[sizeof(disks[disk_count].tag)-1] = '\0';
                        
                        disk_count++;
                    }
                }
            }
        }
    }
    
    fclose(file);
}

DiskInfo* get_disk_info(char disk)
{
    int i;
    ensure_disks_loaded();
    
    for (i = 0; i < disk_count; i++) {
        if (disks[i].disk == disk) {
            return &disks[i];
        }
    }
    return NULL;
}

char* get_disk_path(char disk)
{
    DiskInfo* info = get_disk_info(disk);
    static char default_path[] = ".";
    return (info != NULL) ? info->path : default_path;
}

char* get_disk_label(char disk)
{
    DiskInfo* info = get_disk_info(disk);
    static char default_label[] = "Unknown Disk";
    return (info != NULL) ? info->label : default_label;
}

char* get_disk_tag(char disk)
{
    DiskInfo* info = get_disk_info(disk);
    static char default_tag[] = "";
    return (info != NULL) ? info->tag : default_tag;
}

char* get_current_language(void)
{
    return current_language;
}

/* These functions are kept for compatibility but return minimal implementation */
InfSection* get_section(const char* section_name)
{
    /* This is now a stub function since we don't preload sections */
    return NULL;
}

int get_section_count(void)
{
    /* This is now a stub function since we don't preload sections */
    return 0;
}

void free_resources(void)
{
    /* Since we allocate strings on demand, we don't need to free anything here */
    disk_count = 0;
    inf_filename[0] = '\0';
}
