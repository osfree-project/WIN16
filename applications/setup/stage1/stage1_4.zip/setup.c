#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include <direct.h>
#include <fcntl.h>
#include <io.h>
#include <sys/stat.h>
#include <malloc.h>
#include <dos.h>
#include <stdarg.h>
#include <process.h>
#include "ui.h"
#include "resources.h"
#include "log.h"
#include "dialog.h"
#include "screens.h"
#include "memory.h"

#define MAX_PATH 80
#define MAX_LINE_LENGTH 256

char windowsDir[MAX_PATH] = "C:\\WINDOWS";
char systemDir[MAX_PATH] = "C:\\WINDOWS\\SYSTEM";
char tempDir[MAX_PATH] = "C:\\WINDOWS\\TEMP";
char sourcePath[MAX_PATH] = "";
char logFile[MAX_PATH] = "C:\\SETUP.LOG";
int cpu_type = CPU_8086;
int is386Machine = 0;
int expressSetup = 1;
int setupMode = 0;
char inf_filename[260] = "";

/* Global variables for command line switches */
int ignore_autodetect = 0;
int network_setup = 0;
int admin_setup = 0;
int monochrome_setup = 0;
int scan_incompatible = 0;
char batch_file[MAX_PATH] = "";
char custom_inf[MAX_PATH] = "";
char custom_source[MAX_PATH] = "";

char selected_network[50] = "nonet";  // ��������� ����, �� ��������� "nonet"
int network_installed = 0;            // ���� ��������� ����

/* New function to compare file dates */
int is_source_file_newer(const char *source, const char *dest) {
    struct stat source_stat, dest_stat;
    
    if (stat(source, &source_stat) != 0) {
        return 1; /* Source doesn't exist? Shouldn't happen, but copy anyway */
    }
    
    if (stat(dest, &dest_stat) != 0) {
        return 1; /* Destination doesn't exist, definitely copy */
    }
    
    /* Compare modification times */
    if (source_stat.st_mtime > dest_stat.st_mtime) {
        return 1; /* Source is newer */
    }
    
    return 0; /* Source is older or same */
}

int file_exists(const char *filename) {
    FILE *file = fopen(filename, "rb");
    if (file) {
        fclose(file);
        return 1;
    }
    return 0;
}

long file_size(const char *filename) {
    struct stat st;
    if (stat(filename, &st) == 0) {
        return st.st_size;
    }
    return -1;
}

long get_free_disk_space(const char *path) {
    struct diskfree_t df;
    unsigned drive;
    
    if (path == NULL || strlen(path) < 2) return -1;
    
    drive = toupper(path[0]) - 'A' + 1;
    
    if (_dos_getdiskfree(drive, &df) == 0) {
        return (long)df.avail_clusters * (long)df.bytes_per_sector * (long)df.sectors_per_cluster;
    }
    return -1;
}

void create_directory(const char *path) {
    char tmp[MAX_PATH];
    char *p;
    
    if (path == NULL || strlen(path) == 0) return;
    
    strncpy(tmp, path, sizeof(tmp)-1);
    tmp[sizeof(tmp)-1] = '\0';
    
    /* Skip drive letter */
    p = tmp + 2;
    
    while (*p) {
        if (*p == '\\' || *p == '/') {
            char save_char = *p;
            *p = '\0';
            mkdir(tmp);
            *p = save_char;
        }
        p++;
    }
    mkdir(tmp);
}

int copy_file(const char *source, const char *dest) {
    FILE *src, *dst;
    char buffer[2048];
    size_t bytes;
    char destDir[MAX_PATH];
    char *lastSlash;
    
    if (source == NULL || dest == NULL) return 0;
    
    log_message("Copying file: %s -> %s", source, dest);
    
    src = fopen(source, "rb");
    if (!src) {
        log_message("Error: Cannot open source file %s", source);
        return 0;
    }
    
    strncpy(destDir, dest, sizeof(destDir)-1);
    destDir[sizeof(destDir)-1] = '\0';
    lastSlash = strrchr(destDir, '\\');
    if (lastSlash) {
        *lastSlash = '\0';
        create_directory(destDir);
    }
    
    dst = fopen(dest, "wb");
    if (!dst) {
        log_message("Error: Cannot open destination file %s", dest);
        fclose(src);
        return 0;
    }
    
    while ((bytes = fread(buffer, 1, sizeof(buffer), src)) > 0) {
        if (fwrite(buffer, 1, bytes, dst) != bytes) {
            log_message("Error: Write failed for file %s", dest);
            fclose(src);
            fclose(dst);
            return 0;
        }
    }
    
    fclose(src);
    fclose(dst);
    log_message("Successfully copied: %s", source);
    return 1;
}

/* New function to copy file with version check */
int copy_file_with_version_check(const char *source, const char *dest) {
    /* If it's a new installation, always copy */
    if (setupMode == 0) {
        return copy_file(source, dest);
    }
    
    /* For upgrade mode, check if destination exists */
    if (!file_exists(dest)) {
        log_message("New file in upgrade: %s", dest);
        return copy_file(source, dest);
    }
    
    /* Check if source is newer than destination */
    if (is_source_file_newer(source, dest)) {
        log_message("Upgrading file (source is newer): %s", dest);
        return copy_file(source, dest);
    } else {
        log_message("Skipping file (destination is newer or same): %s", dest);
        return 1; /* Skip copying but return success */
    }
}

int is_compressed_file(const char *filename) {
    FILE *file;
    unsigned char sig[4];
    
    if (filename == NULL) return 0;
    
    file = fopen(filename, "rb");
    if (!file) return 0;
    
    if (fread(sig, 1, 4, file) != 4) {
        fclose(file);
        return 0;
    }
    fclose(file);
    
    return (sig[0] == 'S' && sig[1] == 'Z' && sig[2] == 'D' && sig[3] == 0x88);
}

int expand_file(const char *source, const char *dest) {
    char cmd[512];
    int result;
    
    if (source == NULL || dest == NULL) return 0;
    
    log_message("Expanding compressed file: %s -> %s", source, dest);
    
    if (!is_compressed_file(source)) {
        return copy_file_with_version_check(source, dest);
    }
    
    sprintf(cmd, "expand %s %s", source, dest);
    result = system(cmd);
    
    if (result != 0) {
        log_message("Expand command failed, falling back to copy");
        return copy_file_with_version_check(source, dest);
    }
    
    log_message("Expand command successful");
    return 1;
}

/* Fixed CPU detection - corrected version */
int detect_cpu_type() {
    unsigned short flags1, flags2;
    
    _asm {
        pushf
        pop ax
        mov flags1, ax
        xor ax, 0x4000
        push ax
        popf
        pushf
        pop ax
        mov flags2, ax
        push flags1
        popf
    }
    
    if ((flags1 ^ flags2) & 0x4000) {
        /* 286 or better detected */
        unsigned int result;
        
        _asm {
            ; Try to toggle AC bit in EFLAGS (bit 18) - only works on 386+
            pushf
            pushf
            pop ax
            mov bx, ax
            xor ax, 4000h   ; Try to change bit 18 (AC flag)
            push ax
            popf
            pushf
            pop ax
            popf
            cmp ax, bx
            je not_386
            mov result, 2   ; 386 detected
            jmp done
        not_386:
            mov result, 1   ; 286 detected  
        done:
        }
        
        if (result == 2) {
            log_message("CPU detected: 386");
            return CPU_386;
        } else {
            log_message("CPU detected: 286");
            return CPU_286;
        }
    }
    
    log_message("CPU detected: 8086");
    return CPU_8086;
}

long detect_memory() {
    unsigned short extended_memory = 0;
    _asm {
        mov ah, 0x88
        int 0x15
        mov extended_memory, ax
    }
    return (long)extended_memory * 1024L;
}

void update_autoexec_bat() {
    FILE *autoexec;
    char autoexec_path[MAX_PATH];
    char line[256];
    int path_updated = 0;
    int temp_updated = 0;
    int windir_updated = 0;
    
    /* Try multiple possible locations for AUTOEXEC.BAT */
    const char* possible_paths[] = {
        "C:\\AUTOEXEC.BAT",
        "A:\\AUTOEXEC.BAT", 
        "B:\\AUTOEXEC.BAT",
        NULL
    };
    
    int i;
    for (i = 0; possible_paths[i] != NULL; i++) {
        if (file_exists(possible_paths[i])) {
            strcpy(autoexec_path, possible_paths[i]);
            break;
        }
    }
    
    if (possible_paths[i] == NULL) {
        strcpy(autoexec_path, "C:\\AUTOEXEC.BAT");
    }
    
    /* First check if updates are already present */
    autoexec = fopen(autoexec_path, "rt");
    if (autoexec) {
        while (fgets(line, sizeof(line), autoexec)) {
            if (strstr(line, windowsDir)) path_updated = 1;
            if (strstr(line, "TEMP=") && strstr(line, tempDir)) temp_updated = 1;
            if (strstr(line, "WINDIR=") && strstr(line, windowsDir)) windir_updated = 1;
        }
        fclose(autoexec);
    }
    
    autoexec = fopen(autoexec_path, "at");
    if (autoexec) {
        log_message("Updating AUTOEXEC.BAT at %s", autoexec_path);
        
        if (!path_updated) {
            fprintf(autoexec, "\nSET PATH=%%PATH%%;%s;%s\n", windowsDir, systemDir);
        }
        if (!temp_updated) {
            fprintf(autoexec, "SET TEMP=%s\n", tempDir);
        }
        if (!windir_updated) {
            fprintf(autoexec, "SET WINDIR=%s\n", windowsDir);
        }
        
        fclose(autoexec);
    } else {
        log_message("Warning: Cannot open AUTOEXEC.BAT for update at %s", autoexec_path);
    }
}

void update_config_sys() {
    FILE *config;
    char config_path[MAX_PATH];
    char line[256];
    int files_updated = 0;
    int buffers_updated = 0;
    int stacks_updated = 0;
    
    /* Try multiple possible locations for CONFIG.SYS */
    const char* possible_paths[] = {
        "C:\\CONFIG.SYS",
        "A:\\CONFIG.SYS",
        "B:\\CONFIG.SYS",
        NULL
    };
    
    int i;
    for (i = 0; possible_paths[i] != NULL; i++) {
        if (file_exists(possible_paths[i])) {
            strcpy(config_path, possible_paths[i]);
            break;
        }
    }
    
    if (possible_paths[i] == NULL) {
        strcpy(config_path, "C:\\CONFIG.SYS");
    }
    
    /* First check if updates are already present */
    config = fopen(config_path, "rt");
    if (config) {
        while (fgets(line, sizeof(line), config)) {
            if (strstr(line, "FILES=")) files_updated = 1;
            if (strstr(line, "BUFFERS=")) buffers_updated = 1;
            if (strstr(line, "STACKS=")) stacks_updated = 1;
        }
        fclose(config);
    }
    
    config = fopen(config_path, "at");
    if (config) {
        log_message("Updating CONFIG.SYS at %s", config_path);
        
        if (!files_updated) {
            fprintf(config, "\nFILES=30\n");
        }
        if (!buffers_updated) {
            fprintf(config, "BUFFERS=20\n");
        }
        if (!stacks_updated) {
            fprintf(config, "STACKS=9,256\n");
        }
        
        fclose(config);
    } else {
        log_message("Warning: Cannot open CONFIG.SYS for update at %s", config_path);
    }
}

void setup_directories() {
    log_message("Creating directories: %s, %s", windowsDir, systemDir);
    create_directory(windowsDir);
    create_directory(systemDir);
    /* Don't create TEMP directory here - it will be created when needed */
}

/* Improved function to detect setup mode - check for WIN.COM */
void detect_setup_mode() {
    char win_com_path[MAX_PATH];
    char win_ini_path[MAX_PATH];
    
    log_message("Checking setup mode for directory: %s", windowsDir);
    
    if (file_exists(windowsDir)) {
        /* Check for WIN.COM first */
        sprintf(win_com_path, "%s\\WIN.COM", windowsDir);
        if (file_exists(win_com_path)) {
            setupMode = 1; /* Upgrade mode */
            log_message("Setup mode: Upgrade (WIN.COM exists)");
            return;
        }
        
        /* Also check for WIN.INI as backup */
        sprintf(win_ini_path, "%s\\WIN.INI", windowsDir);
        if (file_exists(win_ini_path)) {
            setupMode = 1; /* Upgrade mode */
            log_message("Setup mode: Upgrade (WIN.INI exists)");
            return;
        }
        
        /* Directory exists but no Windows files found */
        setupMode = 0; /* New installation */
        log_message("Setup mode: New installation (Windows directory exists but no Windows files found)");
    } else {
        setupMode = 0; /* New installation */
        log_message("Setup mode: New installation (Windows directory doesn't exist)");
    }
}

void check_disk_space() {
    long requiredSpace = 0;
    long freeSpace = get_free_disk_space(windowsDir);
    char *minSpaceKey;
    char *minSpace;

    if (setupMode == 0) {
        switch (cpu_type) {
            case CPU_386:
                minSpaceKey = "neededspace386";
                break;
            case CPU_286:
                minSpaceKey = "neededspace286";
                break;
            case CPU_8086:
            default:
                minSpaceKey = "neededspace286";
                break;
        }
    } else {
        switch (cpu_type) {
            case CPU_386:
                requiredSpace = 3000000;
                break;
            case CPU_286:
                requiredSpace = 2000000;
                break;
            case CPU_8086:
            default:
                requiredSpace = 1500000;
                break;
        }
    }

    if (setupMode == 0) {
        minSpace = get_private_profile_string("data", minSpaceKey, NULL, inf_filename);
        if (minSpace) {
            requiredSpace = atol(minSpace);
            xfree(minSpace);
        } else {
            switch (cpu_type) {
                case CPU_386:
                    requiredSpace = 6300000;
                    break;
                case CPU_286:
                    requiredSpace = 4500000;
                    break;
                case CPU_8086:
                default:
                    requiredSpace = 4500000;
                    break;
            }
        }
    }

    log_message("Disk space check - Required: %ld, Available: %ld", requiredSpace, freeSpace);

    if (freeSpace < requiredSpace) {
        char message[100];
        sprintf(message, "Insufficient disk space. Required: %ld, Available: %ld", 
                requiredSpace, freeSpace);
        display_message(message);
        log_message("Fatal: %s", message);
        exit(1);
    }
}

void setup_configuration() {
    char wininiPath[MAX_PATH];
    char systeminiPath[MAX_PATH];
    FILE *winini, *systemini;
    
    /* Only create configuration files for new installations */
    if (setupMode == 1) {
        log_message("Skipping configuration file creation for upgrade mode");
        return;
    }
    
    sprintf(wininiPath, "%s\\WIN.INI", windowsDir);
    winini = fopen(wininiPath, "w");
    if (winini) {
        log_message("Creating WIN.INI");
        fprintf(winini, "[Windows]\n");
        fprintf(winini, "load=\n");
        fprintf(winini, "run=\n");
        fprintf(winini, "Beep=yes\n");
        fprintf(winini, "Spooler=yes\n");
        fprintf(winini, "NullPort=None\n");
        fprintf(winini, "BorderWidth=3\n");
        fprintf(winini, "CursorBlinkRate=530\n");
        fprintf(winini, "DoubleClickSpeed=452\n");
        fprintf(winini, "Programs=com exe bat pif\n");
        fprintf(winini, "Documents=\n");
        fprintf(winini, "DeviceNotSelectedTimeout=15\n");
        fprintf(winini, "TransmissionRetryTimeout=45\n");
        fclose(winini);
    } else {
        log_message("Error: Cannot create WIN.INI");
    }
    
    sprintf(systeminiPath, "%s\\SYSTEM.INI", windowsDir);
    systemini = fopen(systeminiPath, "w");
    if (systemini) {
        log_message("Creating SYSTEM.INI");
        fprintf(systemini, "[boot]\n");
        fprintf(systemini, "shell=progman.exe\n");
        
        switch (cpu_type) {
            case CPU_386:
                fprintf(systemini, "display.drv=vga.drv\n");
                fprintf(systemini, "keyboard.drv=keyboard.drv\n");
                fprintf(systemini, "mouse.drv=mouse.drv\n");
                fprintf(systemini, "fixedfon.fon=vgafix.fon\n");
                fprintf(systemini, "fonts.fon=vgasys.fon\n");
                fprintf(systemini, "oemfonts.fon=vgaoem.fon\n");
                break;
            case CPU_286:
                fprintf(systemini, "display.drv=vga.drv\n");
                fprintf(systemini, "keyboard.drv=keyboard.drv\n");
                fprintf(systemini, "mouse.drv=mouse.drv\n");
                fprintf(systemini, "fixedfon.fon=vgafix.fon\n");
                fprintf(systemini, "fonts.fon=vgasys.fon\n");
                fprintf(systemini, "oemfonts.fon=vgaoem.fon\n");
                break;
            case CPU_8086:
            default:
                fprintf(systemini, "display.drv=ega.drv\n");
                fprintf(systemini, "keyboard.drv=keyboard.drv\n");
                fprintf(systemini, "mouse.drv=mouse.drv\n");
                fprintf(systemini, "fixedfon.fon=egafix.fon\n");
                fprintf(systemini, "fonts.fon=egasys.fon\n");
                fprintf(systemini, "oemfonts.fon=egaoem.fon\n");
                break;
        }
        fclose(systemini);
    } else {
        log_message("Error: Cannot create SYSTEM.INI");
    }
}

/* Fixed function to copy critical setup files */
void copy_setup_files() {
    char source_setup_exe[MAX_PATH];
    char dest_setup_exe[MAX_PATH];
    char dest_setup_inf[MAX_PATH];
    
    /* Copy SETUP.EXE from sourcePath to Windows directory */
    sprintf(source_setup_exe, "%s\\SETUP.EXE", sourcePath);
    sprintf(dest_setup_exe, "%s\\SETUP.EXE", windowsDir);
    
    /* Check if we're not trying to copy the file to the same location */
    if (strcmp(source_setup_exe, dest_setup_exe) != 0) {
        log_message("Copying SETUP.EXE: %s -> %s", source_setup_exe, dest_setup_exe);
        if (!copy_file_with_version_check(source_setup_exe, dest_setup_exe)) {
            log_message("Warning: Failed to copy SETUP.EXE");
        }
    } else {
        log_message("Skipping SETUP.EXE copy (source and destination are the same)");
    }
    
    /* Copy the loaded INF file (from /o or default) to Windows\SYSTEM as SETUP.INF */
    sprintf(dest_setup_inf, "%s\\SYSTEM\\SETUP.INF", windowsDir);
    
    log_message("Copying INF file: %s -> %s", inf_filename, dest_setup_inf);
    if (!copy_file_with_version_check(inf_filename, dest_setup_inf)) {
        log_message("Warning: Failed to copy INF file to %s", dest_setup_inf);
    }
}

/* Improved function to find file copy sections */
int find_file_copy_section(FILE* file, const char* section_name) {
    char line[512];
    char current_section[100] = "";
    int in_target_section = 0;
    char* end;
    
    fseek(file, 0, SEEK_SET);
    
    while (fgets(line, sizeof(line), file) != NULL) {
        line[strcspn(line, "\r\n")] = 0;
        
        if (line[0] == '\0' || line[0] == ';') {
            continue;
        }
        
        if (line[0] == '[') {
            end = strchr(line, ']');
            if (end != NULL) {
                *end = '\0';
                strncpy(current_section, line + 1, sizeof(current_section)-1);
                current_section[sizeof(current_section)-1] = '\0';
                in_target_section = (strcmp(current_section, section_name) == 0);
            } else {
                in_target_section = 0;
            }
            continue;
        }
        
        if (in_target_section) {
            if (strchr(line, '=') != NULL) {
                return 1; /* Found files in this section */
            }
        }
    }
    
    return 0;
}

    /* Helper function to remove disk prefix */
    void remove_disk_prefix(char *str) {
        char *colon = strchr(str, ':');
        if (colon != NULL) {
            memmove(str, colon + 1, strlen(colon + 1) + 1);
        }
    }


/* Function to check if file should be copied based on condition */
int should_copy_file(const char far *condition) {
    size_t cond_len;
    char *near_condition;
    int result;

    if (condition == NULL || condition[0] == '\0') {
        return 1; /* No condition - always copy */
    }
    
    /* Convert far condition to near string for comparison */
    cond_len = _fstrlen(condition);
    near_condition = (char*)xmalloc(cond_len + 1);
    if (near_condition) {
        const char far *src = condition;
        char *dst = near_condition;
        while (cond_len--) {
            *dst++ = *src++;
        }
        *dst = '\0';
    } else {
        return 0; /* Out of memory - skip file */
    }
    
    result = 0;
    
    if (strcmp(near_condition, "Net") == 0) {
        /* Copy if any network is installed */
        result = (strcmp(selected_network, "nonet") != 0);
    } else {
        /* Copy if condition matches selected network */
        result = (strcmp(near_condition, selected_network) == 0);
    }
    
    xfree(near_condition);
    return result;
}

// �������� ������� ������ ���� (��������):
/* Function to select network - stub for now */
void select_network(void) {
    /* For now, default to nonet */
    /* In full implementation, this would show a network selection dialog */
    strcpy(selected_network, "nonet");
    network_installed = 0;
    log_message("Network selected: %s", selected_network);
}

    /* Helper function to parse line with condition */
    void parse_line_with_condition(char *line, char **key, char **value, char **condition) {
        char *first_comma = strchr(line, ',');
        char *second_comma = NULL;
        char *val_end;
        char *key_end;
        
        *key = line;
        *value = line;  // default: value = key
        *condition = NULL;
        
        if (first_comma != NULL) {
            *first_comma = '\0';
            *value = first_comma + 1;
            
            second_comma = strchr(*value, ',');
            if (second_comma != NULL) {
                char *cond_end;

                *second_comma = '\0';
                *condition = second_comma + 1;
                
                // Trim condition
                while (**condition && isspace((unsigned char)**condition)) (*condition)++;
                cond_end = *condition + strlen(*condition) - 1;
                while (cond_end > *condition && isspace((unsigned char)*cond_end)) {
                    *cond_end = '\0';
                    cond_end--;
                }
            }
            
            // Trim value
            while (**value && isspace((unsigned char)**value)) (*value)++;
            val_end = *value + strlen(*value) - 1;
            while (val_end > *value && isspace((unsigned char)*val_end)) {
                *val_end = '\0';
                val_end--;
            }
        }
        
        // Trim key
        while (**key && isspace((unsigned char)**key)) (*key)++;
        key_end = *key + strlen(*key) - 1;
        while (key_end > *key && isspace((unsigned char)*key_end)) {
            *key_end = '\0';
            key_end--;
        }
    }


/* Improved file copying with condition support */
int copy_files() {
    char section_name[50];
    int i, j;
    int total_files, current_file = 0;
    char source_path[MAX_PATH], dest_path[MAX_PATH];
    FILE* file;
    char line[512];
    char current_section[100] = "";
    int in_target_section = 0;
    char* equal_ptr;
    char* key_ptr;
    char* value_ptr;
    char* condition_ptr;
    char* end;
    
    /* Array of possible section names - fixed for C89 compatibility */
    char *possible_sections[7];
    int num_sections = 0;

    char found_section[50] = "";
    int section_found = 0;
    InfSection* section_ptr;
    StringResource far *res;
    
    
    /* First, copy the critical setup files */
    copy_setup_files();
    
    /* Step 1: Copy windows.system files to SYSTEM directory with condition check */
    section_ptr = get_section("windows.system");
    if (section_ptr) {
        log_message("Copying files from [windows.system] section to SYSTEM directory");
        for (j = 0; j < section_ptr->line_count; j++) {
            res = &section_ptr->lines[j];
            if (res->key && res->value) {
              size_t key_len;
              size_t value_len;
              char *near_key;
              char *near_value;

                /* Check condition */
                if (!should_copy_file(res->condition)) {
                    continue; /* Skip file due to condition */
                }
                
                /* Convert far strings to near for sprintf */
                key_len = _fstrlen(res->key);
                value_len = _fstrlen(res->value);
                near_key = (char*)xmalloc(key_len + 1);
                near_value = (char*)xmalloc(value_len + 1);
                
                if (near_key && near_value) {
                    const char far *src_key = res->key;
                    const char far *src_value = res->value;
                    char *dst_key = near_key;
                    char *dst_value = near_value;
                    
                    while (key_len--) *dst_key++ = *src_key++;
                    *dst_key = '\0';
                    
                    while (value_len--) *dst_value++ = *src_value++;
                    *dst_value = '\0';
                    
                    sprintf(source_path, "%s\\%s", sourcePath, near_key);
                    sprintf(dest_path, "%s\\%s", systemDir, near_value);
                    
                    if (!copy_file_with_version_check(source_path, dest_path)) {
                        log_message("Warning: Failed to copy system file: %s", source_path);
                    }
                    
                    xfree(near_key);
                    xfree(near_value);
                }
            }
        }
    } else {
        log_message("Warning: [windows.system] section not found in INF file");
    }
    
    /* Step 2: Copy windows files to WINDOWS directory with condition check */
    section_ptr = get_section("windows");
    if (section_ptr) {
        log_message("Copying files from [windows] section to WINDOWS directory");
        for (j = 0; j < section_ptr->line_count; j++) {
            res = &section_ptr->lines[j];
            if (res->key && res->value) {
                size_t key_len;
                size_t value_len;
                char *near_key;
                char *near_value;

                /* Check condition */
                if (!should_copy_file(res->condition)) {
                    continue; /* Skip file due to condition */
                }
                
                /* Convert far strings to near for sprintf */
                key_len = _fstrlen(res->key);
                value_len = _fstrlen(res->value);
                near_key = (char*)xmalloc(key_len + 1);
                near_value = (char*)xmalloc(value_len + 1);
                
                if (near_key && near_value) {
                    const char far *src_key = res->key;
                    const char far *src_value = res->value;
                    char *dst_key = near_key;
                    char *dst_value = near_value;
                    
                    while (key_len--) *dst_key++ = *src_key++;
                    *dst_key = '\0';
                    
                    while (value_len--) *dst_value++ = *src_value++;
                    *dst_value = '\0';
                    
                    sprintf(source_path, "%s\\%s", sourcePath, near_key);
                    sprintf(dest_path, "%s\\%s", windowsDir, near_value);
                    
                    if (!copy_file_with_version_check(source_path, dest_path)) {
                        log_message("Warning: Failed to copy windows file: %s", source_path);
                    }
                    
                    xfree(near_key);
                    xfree(near_value);
                }
            }
        }
    } else {
        log_message("Warning: [windows] section not found in INF file");
    }
    
    /* Step 3: Copy CPU-specific sections for 386 with condition check */
    if (cpu_type == CPU_386) {
        section_ptr = get_section("windows.system.386");
        if (section_ptr) {
            log_message("Copying files from [windows.system.386] section to SYSTEM directory");
            for (j = 0; j < section_ptr->line_count; j++) {
                res = &section_ptr->lines[j];
                if (res->key && res->value) {
                    size_t key_len;
                    size_t value_len;
                    char *near_key;
                    char *near_value;

                    /* Check condition */
                    if (!should_copy_file(res->condition)) {
                        continue; /* Skip file due to condition */
                    }
                    
                    /* Convert far strings to near for sprintf */
                    key_len = _fstrlen(res->key);
                    value_len = _fstrlen(res->value);
                    near_key = (char*)xmalloc(key_len + 1);
                    near_value = (char*)xmalloc(value_len + 1);
                    
                    if (near_key && near_value) {
                        const char far *src_key = res->key;
                        const char far *src_value = res->value;
                        char *dst_key = near_key;
                        char *dst_value = near_value;
                        
                        while (key_len--) *dst_key++ = *src_key++;
                        *dst_key = '\0';
                        
                        while (value_len--) *dst_value++ = *src_value++;
                        *dst_value = '\0';
                        
                        sprintf(source_path, "%s\\%s", sourcePath, near_key);
                        sprintf(dest_path, "%s\\%s", systemDir, near_value);
                        
                        if (!copy_file_with_version_check(source_path, dest_path)) {
                            log_message("Warning: Failed to copy 386 system file: %s", source_path);
                        }
                        
                        xfree(near_key);
                        xfree(near_value);
                    }
                }
            }
        }
    }
    
    /* Determine the correct section name based on CPU type and setup mode */
    switch (cpu_type) {
        case CPU_386:
            strcpy(section_name, "win.copy.win386");
            break;
        case CPU_286:
        case CPU_8086:
        default:
            strcpy(section_name, "win.copy");
            break;
    }
    
    /* Directly read the file copy section from INF file with condition support */
    file = fopen(inf_filename, "rt");
    if (!file) {
        log_message("Error: Cannot open INF file for reading file copy section: %s", inf_filename);
        display_message("Cannot open INF file for file copy");
        return 0;
    }
    
    /* Build array of possible sections - C89 compatible way */
    possible_sections[num_sections++] = section_name;
    possible_sections[num_sections++] = "win.copy.386";
    possible_sections[num_sections++] = "win.copy.286";
    possible_sections[num_sections++] = "win.copy.86";
    possible_sections[num_sections++] = "files";
    possible_sections[num_sections++] = "win.files";
    possible_sections[num_sections] = NULL;
    
    for (i = 0; i < num_sections; i++) {
        if (find_file_copy_section(file, possible_sections[i])) {
            strcpy(found_section, possible_sections[i]);
            section_found = 1;
            log_message("Found file copy section: [%s]", found_section);
            break;
        }
    }
    
    if (!section_found) {
        log_message("Error: No file copy section found in INF file");
        display_message("No file copy section found in INF file");
        fclose(file);
        return 0;
    }
    
    /* Count files in the found section */
    total_files = 0;
    fseek(file, 0, SEEK_SET);
    in_target_section = 0;
    
    while (fgets(line, sizeof(line), file) != NULL) {
        line[strcspn(line, "\r\n")] = 0;
        
        if (line[0] == '\0' || line[0] == ';') {
            continue;
        }
        
        if (line[0] == '[') {
            end = strchr(line, ']');
            if (end != NULL) {
                *end = '\0';
                strncpy(current_section, line + 1, sizeof(current_section)-1);
                current_section[sizeof(current_section)-1] = '\0';
                in_target_section = (strcmp(current_section, found_section) == 0);
            } else {
                in_target_section = 0;
            }
            continue;
        }
        
        if (in_target_section) {
            equal_ptr = strchr(line, '=');
            if (equal_ptr != NULL) {
                total_files++;
            }
        }
    }
    
    if (total_files == 0) {
        log_message("Error: No files found in section [%s]", found_section);
        display_message("No files found in file copy section");
        fclose(file);
        return 0;
    }
    
    log_message("Starting file copy from main section: %d files to copy from section [%s]", total_files, found_section);
    
    /* Copy files from the found section with condition support */
    fseek(file, 0, SEEK_SET);
    current_file = 0;
    in_target_section = 0;
    
    while (fgets(line, sizeof(line), file) != NULL) {
        line[strcspn(line, "\r\n")] = 0;
        
        if (line[0] == '\0' || line[0] == ';') {
            continue;
        }
        
        if (line[0] == '[') {
            end = strchr(line, ']');
            if (end != NULL) {
                *end = '\0';
                strncpy(current_section, line + 1, sizeof(current_section)-1);
                current_section[sizeof(current_section)-1] = '\0';
                in_target_section = (strcmp(current_section, found_section) == 0);
            } else {
                in_target_section = 0;
            }
            continue;
        }
        
        if (in_target_section) {
            equal_ptr = strchr(line, '=');
            if (equal_ptr != NULL) {
                *equal_ptr = '\0';
                key_ptr = line;
                value_ptr = equal_ptr + 1;
                condition_ptr = NULL;
                
                /* Parse condition if present */
                parse_line_with_condition(value_ptr, &value_ptr, &value_ptr, &condition_ptr);
                
                /* Remove disk prefixes */
                if (key_ptr[0] != '#') { /* Don't remove from section references */
                    remove_disk_prefix(key_ptr);
                    remove_disk_prefix(value_ptr);
                }
                
                /* Trim whitespace */
                while (*key_ptr && isspace((unsigned char)*key_ptr)) key_ptr++;
                end = key_ptr + strlen(key_ptr) - 1;
                while (end > key_ptr && isspace((unsigned char)*end)) {
                    *end = '\0';
                    end--;
                }
                
                while (*value_ptr && isspace((unsigned char)*value_ptr)) value_ptr++;
                end = value_ptr + strlen(value_ptr) - 1;
                while (end > value_ptr && isspace((unsigned char)*end)) {
                    *end = '\0';
                    end--;
                }
                
                /* Skip empty lines or comments */
                if (strlen(key_ptr) == 0 || strlen(value_ptr) == 0) {
                    continue;
                }
                
                /* Check condition */
                if (condition_ptr && condition_ptr[0] != '\0') {
                    if (!should_copy_file((const char far *)condition_ptr)) {
                        continue; /* Skip due to condition */
                    }
                }
                
                current_file++;
                display_progress(current_file, total_files, "Please wait while Setup copies files to your hard disk.");
                
                sprintf(source_path, "%s\\%s", sourcePath, key_ptr);
                sprintf(dest_path, "%s\\%s", windowsDir, value_ptr);
                
                if (!copy_file_with_version_check(source_path, dest_path)) {
                    if (!display_file_error(source_path)) {
                        log_message("File copy aborted by user");
                        break;
                    } else {
                        log_message("Retrying file: %s", source_path);
                        current_file--;
                    }
                }
            }
        }
    }
    
    fclose(file);
    log_message("File copy completed: %d of %d files copied", current_file, total_files);
    return 1;
}

/* Fixed stage2 launch to prevent looping */
int launch_stage2(void) {
    char win_com_path[MAX_PATH];
    char command[512];
    
    /* Only try to launch Windows, not setup again */
    sprintf(win_com_path, "%s\\WIN.COM", windowsDir);
    
    if (file_exists(win_com_path)) {
        log_message("Launching Windows: %s", win_com_path);
        printf("\nSetup completed successfully. Launching Windows...\n");
        
        /* Use system call instead of spawn to avoid memory issues */
        sprintf(command, "%s", win_com_path);
        return system(command);
    }
    
    /* If WIN.COM not found, just exit successfully */
    log_message("Windows setup completed. WIN.COM not found, exiting.");
    printf("\nWindows setup completed successfully.\n");
    printf("You can now run Windows by typing WIN at the command prompt.\n");
    return 0;
}

/* ������� ��� ����������� ������� �� ������ ��������� ������ */
void display_command_line_help(void) {
    printf("Windows Setup Command Line Switches:\n\n");
    printf("/?      Display this help message\n");
    printf("/i      Ignore automatic hardware detection\n");
    printf("/n      Set up a shared copy of Windows from a network server\n");
    printf("/a      Administrative Setup: copy all files to network server and mark as read-only\n");
    printf("/b      Set up Windows with monochrome display attributes\n");
    printf("/t      Search for incompatible software (for maintenance only)\n");
    printf("/h:filename Run Batch Mode Setup using the specified system settings file\n");
    printf("/o:filename Specify the SETUP.INF file\n");
    printf("/s:filename Specify the path for Windows installation disks\n\n");
}

/* ������� ��� �������� ������ ��������� ������ */
void parse_command_line(int argc, char *argv[]) {
    int i;
    
    for (i = 1; i < argc; i++) {
        if (argv[i][0] == '/' || argv[i][0] == '-') {
            if (strlen(argv[i]) < 2) {
                log_message("Warning: Invalid command line switch: %s", argv[i]);
                continue;
            }
            
            switch (tolower(argv[i][1])) {
                case '?':
                    display_command_line_help();
                    exit(0);
                    break;
                    
                case 'i':
                    ignore_autodetect = 1;
                    log_message("Command line: /i - Ignore automatic hardware detection");
                    break;
                    
                case 'n':
                    network_setup = 1;
                    log_message("Command line: /n - Network setup");
                    break;
                    
                case 'a':
                    admin_setup = 1;
                    log_message("Command line: /a - Administrative setup");
                    break;
                    
                case 'b':
                    monochrome_setup = 1;
                    log_message("Command line: /b - Monochrome display");
                    break;
                    
                case 't':
                    scan_incompatible = 1;
                    log_message("Command line: /t - Scan for incompatible software");
                    break;
                    
                case 'h':
                    if (strlen(argv[i]) > 3 && argv[i][2] == ':') {
                        strncpy(batch_file, argv[i] + 3, sizeof(batch_file) - 1);
                        batch_file[sizeof(batch_file)-1] = '\0';
                        log_message("Command line: /h:%s - Batch mode setup", batch_file);
                    } else {
                        log_message("Warning: Invalid /h switch format: %s", argv[i]);
                    }
                    break;
                    
                case 'o':
                    if (strlen(argv[i]) > 3 && argv[i][2] == ':') {
                        strncpy(custom_inf, argv[i] + 3, sizeof(custom_inf) - 1);
                        custom_inf[sizeof(custom_inf)-1] = '\0';
                        log_message("Command line: /o:%s - Custom INF file", custom_inf);
                    } else {
                        log_message("Warning: Invalid /o switch format: %s", argv[i]);
                    }
                    break;
                    
                case 's':
                    if (strlen(argv[i]) > 3 && argv[i][2] == ':') {
                        strncpy(custom_source, argv[i] + 3, sizeof(custom_source) - 1);
                        custom_source[sizeof(custom_source)-1] = '\0';
                        log_message("Command line: /s:%s - Custom source path", custom_source);
                    } else {
                        log_message("Warning: Invalid /s switch format: %s", argv[i]);
                    }
                    break;
                    
                default:
                    log_message("Warning: Unknown command line switch: %s", argv[i]);
                    break;
            }
        } else {
            /* ���� �������� ��� �����, ������� ��� ����� � �������� ������ */
            if (sourcePath[0] == '\0') {
                strncpy(sourcePath, argv[i], sizeof(sourcePath) - 1);
                sourcePath[sizeof(sourcePath)-1] = '\0';
                log_message("Command line: source path = %s", sourcePath);
            }
        }
    }
}

int main(int argc, char *argv[]) {
    char* defdir;
    int i;
    int copy_result;

    setbuf(stdout, NULL);

    log_init(logFile);
    log_message("Windows Setup started");

    log_message("Command line: %d arguments", argc);
    
    for (i = 0; i < argc; i++) {
        log_message("  argv[%d]: %s", i, argv[i]);
    }

    /* ������� ������ ��������� ������ */
    parse_command_line(argc, argv);
    
    /* ��������� ����� /s - ���� � �������� ������ */
    if (custom_source[0] != '\0') {
        strcpy(sourcePath, custom_source);
        log_message("Using custom source path from /s: %s", sourcePath);
    }
    
    /* ���� ���� � �������� ������ �� ������, ���������� ������� ������� */
    if (sourcePath[0] == '\0') {
        if (getcwd(sourcePath, sizeof(sourcePath)) == NULL) {
            log_message("Error: Cannot get current directory, using C:\\");
            strcpy(sourcePath, "C:\\");
        }
        log_message("Source path from current directory: %s", sourcePath);
    }
    
    /* ��������� ����� /o - ���������������� INF ���� */
    if (custom_inf[0] != '\0') {
        /* ���� ������ /o, ���������� ��������� ���� ��� SETUP.INF */
        strcpy(inf_filename, custom_inf);
        log_message("Using custom INF file from /o: %s", inf_filename);
    } else {
        /* ����� ���������� SETUP.INF �� sourcePath */
        /* Fix double backslash issue */
        if (sourcePath[strlen(sourcePath)-1] == '\\') {
            sprintf(inf_filename, "%sSETUP.INF", sourcePath);
        } else {
            sprintf(inf_filename, "%s\\SETUP.INF", sourcePath);
        }
        log_message("Using default INF file: %s", inf_filename);
    }
    
    log_message("UI initialization starting");
    init_ui();
    log_message("UI initialized");
    
    /* ���������� ����� ������ SETUP.INF */
    setup_loading_screen();
    
    log_message("Loading INF file: %s", inf_filename);
    
    if (!file_exists(inf_filename)) {
        char error_msg[300];
        sprintf(error_msg, 
                 "Setup is having trouble opening %s.", inf_filename);
        
        display_error_dialog(
            error_msg,
            "Please check your Windows disk to see if", 
            "this file is available."
        );
        
        log_message("Error: INF file not found at %s", inf_filename);
        log_close();
        return 1;
    }
    
    load_inf_file(inf_filename);
    log_message("INF file loaded successfully, sections found: %d", get_section_count());
    
    /* ��������� ����� /i - ������������ �������������� ����������� */
    if (!ignore_autodetect) {
        cpu_type = detect_cpu_type();
        log_message("Detected CPU type: %d", cpu_type);
    } else {
        log_message("Automatic hardware detection disabled by /i switch");
        /* Use default CPU type or determine from other factors */
        cpu_type = CPU_286; /* Reasonable default */
    }
    
    /* Get default directory directly from INF file */
    defdir = get_private_profile_string("data", "defdir", "C:\\WINDOWS", inf_filename);
    if (defdir != NULL) {
        strcpy(windowsDir, defdir);
        sprintf(systemDir, "%s\\SYSTEM", windowsDir);
        sprintf(tempDir, "%s\\TEMP", windowsDir);
        log_message("Using directory from INF: %s", windowsDir);
        xfree(defdir);
    } else {
        log_message("Using default directory: %s", windowsDir);
    }
    
    /* Now detect setup mode AFTER getting directory but BEFORE welcome screen */
    detect_setup_mode();
    
    /* Select network before file copying */
    select_network();
    
    /* ����� 1: Welcome screen */
    setup_welcome();
    
    /* ����� 2: Directory selection */
    setup_directory_menu(windowsDir);
    sprintf(systemDir, "%s\\SYSTEM", windowsDir);
    sprintf(tempDir, "%s\\TEMP", windowsDir);
    log_message("Directory selected: %s", windowsDir);
    
    /* Re-detect setup mode after directory selection in case user changed it */
    detect_setup_mode();

    
    /* ����� 3: Configuration confirmation */
    display_configuration_confirmation(windowsDir, setupMode ? "Upgrade" : "Express");
    
    check_disk_space();
    
    /* Only create directories for new installations */
    if (setupMode == 0) {
        setup_directories();
    } else {
        log_message("Skipping directory creation for upgrade mode");
    }
    
    /* ����� 4: File copy progress */
    copy_result = copy_files();
    
    /* Only setup configuration for new installations */
    setup_configuration();
    
    /* Only update system files for new installations */
    if (setupMode == 0) {
        update_autoexec_bat();
        update_config_sys();
    } else {
        log_message("Skipping system file updates for upgrade mode");
    }
    
    /* ����� 5: Completion screen */
    display_completion_screen();
    
    if (copy_result) {
        log_message("Windows Setup stage1 completed successfully");
    } else {
        log_message("Windows Setup completed with errors");
    }
    
    free_resources();
    
    /* Launch stage2 setup only if file copy was successful */
    if (copy_result) {
        log_message("Attempting to launch Windows...");
        launch_stage2();
    } else {
        log_message("Not launching Windows due to file copy errors");
        printf("\nSetup completed with errors. Some files may not have been copied.\n");
    }
    
    log_close();
    
    return copy_result ? 0 : 1;
}
