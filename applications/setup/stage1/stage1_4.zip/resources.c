#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>
#include "resources.h"
#include "memory.h"

static DiskInfo disk_info[MAX_DISKS];
static int disk_count = 0;

static InfSection sections[MAX_SECTIONS];
static int section_count = 0;
static char current_language[MAX_LANGUAGE_LENGTH] = "usa";

/* Helper function to duplicate string to far memory */
static char far * far_strdup(const char *str) {
    unsigned int len;
    const char *src;
    char far *dst;
    char far *far_str;
    
    if (!str) return NULL;
    
    /* Calculate length manually to avoid size_t issues */
    len = 0;
    src = str;
    while (*src++) len++;
    
    far_str = (char far *)xfarmalloc(len + 1);
    if (far_str) {
        src = str;
        dst = far_str;
        while (len--) {
            *dst++ = *src++;
        }
        *dst = '\0';
    }
    return far_str;
}

/* Helper function to check if current section is a file list section */
static int is_file_list_section(const char *section_name) {
    return (strcmp(section_name, "windows.system") == 0 ||
            strcmp(section_name, "windows") == 0 ||
            strcmp(section_name, "windows.system.386") == 0 ||
            strcmp(section_name, "win.copy") == 0 ||
            strcmp(section_name, "win.copy.win386") == 0 ||
            strcmp(section_name, "win.copy.386") == 0 ||
            strcmp(section_name, "win.copy.286") == 0);
}

/* Helper function to remove disk prefix from filename */
static void remove_disk_prefix(char *filename) {
    char *colon_pos = strchr(filename, ':');
    if (colon_pos != NULL) {
        /* Move the part after colon to beginning */
        memmove(filename, colon_pos + 1, strlen(colon_pos + 1) + 1);
    }
}

/* Helper function to parse file list line (format: "source" or "source,destination" or "source,destination,condition") */
static void parse_file_list_line(char *line, char *key, char *value, char *condition, int max_len) {
    char *comma_pos;
    char *second_comma;
    char *temp;
    
    /* Initialize */
    key[0] = '\0';
    value[0] = '\0';
    if (condition) condition[0] = '\0';
    
    /* Find first comma separator */
    comma_pos = strchr(line, ',');
    
    if (comma_pos != NULL) {
        /* Split line into source and the rest */
        *comma_pos = '\0';
        
        /* Source file (key) */
        strncpy(key, line, max_len - 1);
        key[max_len - 1] = '\0';
        
        /* Now look for second comma - this would be condition */
        second_comma = strchr(comma_pos + 1, ',');
        if (second_comma != NULL) {
            /* We have source,destination,condition format */
            *second_comma = '\0';
            strncpy(value, comma_pos + 1, max_len - 1);
            value[max_len - 1] = '\0';
            if (condition) {
                strncpy(condition, second_comma + 1, max_len - 1);
                condition[max_len - 1] = '\0';
            }
        } else {
            /* Only one comma - could be source,destination or source,condition */
            /* Check if the part after comma looks like a condition (not a filename) */
            char *after_comma = comma_pos + 1;
            int is_condition = 0;
            
            /* Conditions are typically short words like "Net", not file paths */
            if (strlen(after_comma) < 20 && !strchr(after_comma, '\\') && !strchr(after_comma, '.')) {
                is_condition = 1;
            }
            
            if (is_condition) {
                /* source,condition format - use source as destination */
                strncpy(value, line, max_len - 1);  // destination = source
                value[max_len - 1] = '\0';
                if (condition) {
                    strncpy(condition, after_comma, max_len - 1);
                    condition[max_len - 1] = '\0';
                }
            } else {
                /* source,destination format */
                strncpy(value, after_comma, max_len - 1);
                value[max_len - 1] = '\0';
            }
        }
    } else {
        /* No comma - use same file for source and destination */
        strncpy(key, line, max_len - 1);
        key[max_len - 1] = '\0';
        strncpy(value, line, max_len - 1);
        value[max_len - 1] = '\0';
    }
    
    /* Remove disk prefixes from key and value */
    remove_disk_prefix(key);
    remove_disk_prefix(value);
    
    /* Trim whitespace from key */
    temp = key;
    while (*temp && isspace((unsigned char)*temp)) temp++;
    if (temp != key) {
        memmove(key, temp, strlen(temp) + 1);
    }
    temp = key + strlen(key) - 1;
    while (temp > key && isspace((unsigned char)*temp)) {
        *temp = '\0';
        temp--;
    }
    
    /* Trim whitespace from value */
    temp = value;
    while (*temp && isspace((unsigned char)*temp)) temp++;
    if (temp != value) {
        memmove(value, temp, strlen(temp) + 1);
    }
    temp = value + strlen(value) - 1;
    while (temp > value && isspace((unsigned char)*temp)) {
        *temp = '\0';
        temp--;
    }
    
    /* Trim whitespace from condition if present */
    if (condition) {
        temp = condition;
        while (*temp && isspace((unsigned char)*temp)) temp++;
        if (temp != condition) {
            memmove(condition, temp, strlen(temp) + 1);
        }
        temp = condition + strlen(condition) - 1;
        while (temp > condition && isspace((unsigned char)*temp)) {
            *temp = '\0';
            temp--;
        }
    }
}

void load_inf_file(const char* filename) {
    FILE* file;
    char line[512];
    char current_section[100] = "";
    InfSection* current_section_ptr = NULL;
    char* pos;
    char* equal_sign;
    char* key_ptr;
    char* value_ptr;
    char* temp;
    StringResource far *res;
    int i, j;
    int new_alloc;
    StringResource far *new_lines;
    char key_buf[MAX_KEY_LENGTH];
    char value_buf[MAX_VALUE_LENGTH];
    char condition_buf[MAX_VALUE_LENGTH];
    
    /* Clear existing sections */
    for (i = 0; i < section_count; i++) {
        if (sections[i].lines) {
            for (j = 0; j < sections[i].line_count; j++) {
                if (sections[i].lines[j].key) {
                    xfarfree(sections[i].lines[j].key);
                }
                if (sections[i].lines[j].value) {
                    xfarfree(sections[i].lines[j].value);
                }
                if (sections[i].lines[j].condition) {
                    xfarfree(sections[i].lines[j].condition);
                }
            }
            xfarfree(sections[i].lines);
        }
    }
    section_count = 0;
    disk_count = 0;
    
    file = fopen(filename, "rt");
    if (!file) {
        return;
    }

    while (fgets(line, sizeof(line), file)) {
        /* Remove newline characters */
        line[strcspn(line, "\r\n")] = '\0';
        
        /* Skip empty lines and comments */
        if (line[0] == '\0' || line[0] == ';') {
            continue;
        }

        /* Check for section header */
        if (line[0] == '[') {
            pos = strchr(line, ']');
            if (pos) {
                *pos = '\0';
                strncpy(current_section, line + 1, sizeof(current_section) - 1);
                current_section[sizeof(current_section) - 1] = '\0';
                
                /* Find or create section */
                current_section_ptr = NULL;
                for (i = 0; i < section_count; i++) {
                    if (strcmp(sections[i].name, current_section) == 0) {
                        current_section_ptr = &sections[i];
                        break;
                    }
                }
                
                if (!current_section_ptr && section_count < MAX_SECTIONS) {
                    current_section_ptr = &sections[section_count];
                    strncpy(current_section_ptr->name, current_section, 
                           sizeof(current_section_ptr->name) - 1);
                    current_section_ptr->name[sizeof(current_section_ptr->name) - 1] = '\0';
                    current_section_ptr->lines = NULL;
                    current_section_ptr->line_count = 0;
                    current_section_ptr->lines_allocated = 0;
                    section_count++;
                }
            }
            continue;
        }

        /* Process disks section */
        if (strcmp(current_section, "disks") == 0) {
            if (disk_count < MAX_DISKS) {
                char disk_char;
                char path[300], label[300], tag[300];
                int scan_count;
                
                /* Parse disk line format: n = path,"disk name","disk tag" */
                scan_count = sscanf(line, "%c =%[^,],%[^,],%s", 
                          &disk_char, path, label, tag);
                if (scan_count == 4) {
                    /* Remove quotes from labels if present */
                    if (label[0] == '"' && label[strlen(label)-1] == '"') {
                        memmove(label, label+1, strlen(label)-2);
                        label[strlen(label)-2] = '\0';
                    }
                    if (tag[0] == '"' && tag[strlen(tag)-1] == '"') {
                        memmove(tag, tag+1, strlen(tag)-2);
                        tag[strlen(tag)-2] = '\0';
                    }
                    
                    /* Trim whitespace from path */
                    temp = path;
                    while (*temp && isspace((unsigned char)*temp)) temp++;
                    if (temp != path) {
                        strcpy(path, temp);
                    }
                    temp = path + strlen(path) - 1;
                    while (temp > path && isspace((unsigned char)*temp)) {
                        *temp = '\0';
                        temp--;
                    }
                    
                    disk_info[disk_count].disk = disk_char;
                    strncpy(disk_info[disk_count].path, path, sizeof(disk_info[disk_count].path)-1);
                    disk_info[disk_count].path[sizeof(disk_info[disk_count].path)-1] = '\0';
                    strncpy(disk_info[disk_count].label, label, sizeof(disk_info[disk_count].label)-1);
                    disk_info[disk_count].label[sizeof(disk_info[disk_count].label)-1] = '\0';
                    strncpy(disk_info[disk_count].tag, tag, sizeof(disk_info[disk_count].tag)-1);
                    disk_info[disk_count].tag[sizeof(disk_info[disk_count].tag)-1] = '\0';
                    disk_count++;
                }
            }
            continue;
        }

        /* Check if we're in a file list section */
        if (current_section_ptr && is_file_list_section(current_section)) {
            /* Parse file list format with condition support */
            parse_file_list_line(line, key_buf, value_buf, condition_buf, MAX_KEY_LENGTH);
            
            /* Skip if key is empty */
            if (strlen(key_buf) == 0) {
                continue;
            }
            
            /* Allocate more memory if needed */
            if (current_section_ptr->line_count >= current_section_ptr->lines_allocated) {
                new_alloc = current_section_ptr->lines_allocated == 0 ? 50 : current_section_ptr->lines_allocated * 2;
                if (new_alloc > MAX_LINES) {
                    new_alloc = MAX_LINES;
                }
                
                new_lines = (StringResource far *)xfarmalloc(new_alloc * sizeof(StringResource));
                if (!new_lines) {
                    continue; /* Out of memory */
                }
                
                if (current_section_ptr->lines) {
                    _fmemcpy(new_lines, current_section_ptr->lines, 
                            current_section_ptr->line_count * sizeof(StringResource));
                    xfarfree(current_section_ptr->lines);
                }
                
                current_section_ptr->lines = new_lines;
                current_section_ptr->lines_allocated = new_alloc;
            }
            
            if (current_section_ptr->line_count < current_section_ptr->lines_allocated) {
                /* Add the key-value pair with condition */
                res = &current_section_ptr->lines[current_section_ptr->line_count];
                res->key = far_strdup(key_buf);
                res->value = far_strdup(value_buf);
                res->condition = far_strdup(condition_buf);
                
                if (res->key && res->value) {
                    current_section_ptr->line_count++;
                } else {
                    /* Cleanup if allocation failed */
                    if (res->key) xfarfree(res->key);
                    if (res->value) xfarfree(res->value);
                    if (res->condition) xfarfree(res->condition);
                }
            }
            continue;
        }

        /* Process regular key-value pairs for other sections */
        if (current_section_ptr && (equal_sign = strchr(line, '=')) != NULL) {
            *equal_sign = '\0';
            key_ptr = line;
            value_ptr = equal_sign + 1;
            
            /* Trim whitespace from key */
            while (*key_ptr && isspace((unsigned char)*key_ptr)) key_ptr++;
            temp = key_ptr + strlen(key_ptr) - 1;
            while (temp > key_ptr && isspace((unsigned char)*temp)) {
                *temp = '\0';
                temp--;
            }
            
            /* Trim whitespace from value */
            while (*value_ptr && isspace((unsigned char)*value_ptr)) value_ptr++;
            temp = value_ptr + strlen(value_ptr) - 1;
            while (temp > value_ptr && isspace((unsigned char)*temp)) {
                *temp = '\0';
                temp--;
            }
            
            /* Remove quotes from value if present */
            if (value_ptr[0] == '"' && value_ptr[strlen(value_ptr)-1] == '"') {
                memmove(value_ptr, value_ptr+1, strlen(value_ptr)-2);
                value_ptr[strlen(value_ptr)-2] = '\0';
            }
            
            /* Skip if key is empty */
            if (strlen(key_ptr) == 0) {
                continue;
            }
            
            /* Allocate more memory if needed */
            if (current_section_ptr->line_count >= current_section_ptr->lines_allocated) {
                new_alloc = current_section_ptr->lines_allocated == 0 ? 50 : current_section_ptr->lines_allocated * 2;
                if (new_alloc > MAX_LINES) {
                    new_alloc = MAX_LINES;
                }
                
                new_lines = (StringResource far *)xfarmalloc(new_alloc * sizeof(StringResource));
                if (!new_lines) {
                    continue; /* Out of memory */
                }
                
                if (current_section_ptr->lines) {
                    _fmemcpy(new_lines, current_section_ptr->lines, 
                            current_section_ptr->line_count * sizeof(StringResource));
                    xfarfree(current_section_ptr->lines);
                }
                
                current_section_ptr->lines = new_lines;
                current_section_ptr->lines_allocated = new_alloc;
            }
            
            if (current_section_ptr->line_count < current_section_ptr->lines_allocated) {
                /* Add the key-value pair */
                res = &current_section_ptr->lines[current_section_ptr->line_count];
                res->key = far_strdup(key_ptr);
                res->value = far_strdup(value_ptr);
                res->condition = NULL;  /* No condition for regular key-value pairs */
                
                if (res->key && res->value) {
                    current_section_ptr->line_count++;
                } else {
                    /* Cleanup if allocation failed */
                    if (res->key) xfarfree(res->key);
                    if (res->value) xfarfree(res->value);
                }
            }
        }
    }
    
    fclose(file);
}

char* get_string(const char* section, const char* key) {
    return get_string_default(section, key, NULL);
}

char* get_string_default(const char* section, const char* key, const char* default_value) {
    int i, j;
    StringResource far *res;
    char* result;
    unsigned int len;
    const char far *src;
    char *dst;
    
    for (i = 0; i < section_count; i++) {
        if (strcmp(sections[i].name, section) == 0) {
            for (j = 0; j < sections[i].line_count; j++) {
                res = &sections[i].lines[j];
                if (res->key && _fstrcmp(res->key, (const char far *)key) == 0) {
                    len = _fstrlen(res->value);
                    result = (char*)xmalloc(len + 1);
                    if (result) {
                        /* Copy from far to near memory */
                        src = res->value;
                        dst = result;
                        while (len--) {
                            *dst++ = *src++;
                        }
                        *dst = '\0';
                    }
                    return result;
                }
            }
            break;
        }
    }
    
    if (default_value) {
        result = (char*)xmalloc(strlen(default_value) + 1);
        if (result) {
            strcpy(result, default_value);
        }
        return result;
    }
    
    return NULL;
}

char* get_string_for_cpu(const char* base_section, const char* key, int cpu_type) {
    char section_name[100];
    char* result;
    
    if (cpu_type == CPU_386) {
        sprintf(section_name, "%s.win386", base_section);
        result = get_string(section_name, key);
        if (result) return result;
        
        sprintf(section_name, "%s.386", base_section);
        result = get_string(section_name, key);
        if (result) return result;
    } else if (cpu_type == CPU_286) {
        sprintf(section_name, "%s.286", base_section);
        result = get_string(section_name, key);
        if (result) return result;
    }
    
    return get_string(base_section, key);
}

int get_int(const char* section, const char* key, int default_value) {
    char* str_val;
    int result;
    
    str_val = get_string(section, key);
    if (str_val) {
        result = atoi(str_val);
        xfree(str_val);
        return result;
    }
    return default_value;
}

DiskInfo* get_disk_info(char disk) {
    int i;
    
    for (i = 0; i < disk_count; i++) {
        if (disk_info[i].disk == disk) {
            return &disk_info[i];
        }
    }
    
    return NULL;
}

char* get_disk_path(char disk) {
    DiskInfo* info;
    char* result;
    
    info = get_disk_info(disk);
    if (info && info->path[0]) {
        result = (char*)xmalloc(strlen(info->path) + 1);
        if (result) {
            strcpy(result, info->path);
        }
        return result;
    }
    return NULL;
}

char* get_disk_label(char disk) {
    DiskInfo* info;
    char* result;
    
    info = get_disk_info(disk);
    if (info && info->label[0]) {
        result = (char*)xmalloc(strlen(info->label) + 1);
        if (result) {
            strcpy(result, info->label);
        }
        return result;
    }
    return NULL;
}

char* get_disk_tag(char disk) {
    DiskInfo* info;
    char* result;
    
    info = get_disk_info(disk);
    if (info && info->tag[0]) {
        result = (char*)xmalloc(strlen(info->tag) + 1);
        if (result) {
            strcpy(result, info->tag);
        }
        return result;
    }
    return NULL;
}

char* get_current_language(void) {
    char* result;
    
    result = (char*)xmalloc(strlen(current_language) + 1);
    if (result) {
        strcpy(result, current_language);
    }
    return result;
}

InfSection* get_section(const char* section_name) {
    int i;
    
    for (i = 0; i < section_count; i++) {
        if (strcmp(sections[i].name, section_name) == 0) {
            return &sections[i];
        }
    }
    return NULL;
}

void free_resources(void) {
    int i, j;
    StringResource far *res;
    
    for (i = 0; i < section_count; i++) {
        if (sections[i].lines) {
            for (j = 0; j < sections[i].line_count; j++) {
                res = &sections[i].lines[j];
                if (res->key) xfarfree(res->key);
                if (res->value) xfarfree(res->value);
                if (res->condition) xfarfree(res->condition);
            }
            xfarfree(sections[i].lines);
            sections[i].lines = NULL;
        }
        sections[i].line_count = 0;
        sections[i].lines_allocated = 0;
    }
    section_count = 0;
    disk_count = 0;
}

int get_section_count(void) {
    return section_count;
}

char* get_private_profile_string(const char* section, const char* key, 
                                const char* default_val, const char* filename) {
    /* For now, use the already loaded INF file data */
    return get_string_default(section, key, default_val);
}

int get_private_profile_int(const char* section, const char* key, 
                           int default_val, const char* filename) {
    char* str_val;
    int result;
    
    str_val = get_private_profile_string(section, key, NULL, filename);
    if (str_val) {
        result = atoi(str_val);
        xfree(str_val);
        return result;
    }
    return default_val;
}
