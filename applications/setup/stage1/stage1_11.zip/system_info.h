#ifndef SYSTEM_INFO_H
#define SYSTEM_INFO_H

int detect_cpu_type(void);
long detect_memory(void);

#endif
