#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>
#include "resources.h"
#include "memory.h"
#include "log.h"

static DiskInfo disk_info[MAX_DISKS];
static int disk_count = 0;

static InfSection sections[MAX_SECTIONS];
static int section_count = 0;
static char current_language[MAX_LANGUAGE_LENGTH] = "usa";

/* FIXED: Array for parsed machine entries */
static MachineEntry machine_entries[MAX_SECTIONS];
static int machine_entry_count = 0;

/* Helper function to duplicate string to far memory */
static char far * far_strdup(const char *str) {
    unsigned int len;
    const char *src;
    char far *dst;
    char far *far_str;
    
    if (!str) return NULL;
    
    /* Calculate length manually to avoid size_t issues */
    len = 0;
    src = str;
    while (*src++) len++;
    
    far_str = (char far *)xfarmalloc(len + 1);
    if (far_str) {
        src = str;
        dst = far_str;
        while (len--) {
            *dst++ = *src++;
        }
        *dst = '\0';
    }
    return far_str;
}

/* Helper function to remove disk prefix from filename */
static void remove_disk_prefix(char *filename) {
    char *colon_pos = strchr(filename, ':');
    if (colon_pos != NULL) {
        /* Move the part after colon to beginning */
        memmove(filename, colon_pos + 1, strlen(colon_pos + 1) + 1);
    }
}

/* Helper function to add a line to a section */
static int add_section_line(InfSection* section, const char* key, const char* value, const char* condition) {
    int new_alloc;
    StringResource far *new_lines;
    StringResource far *res;
    
    if (section->line_count >= section->lines_allocated) {
        new_alloc = section->lines_allocated == 0 ? 10 : section->lines_allocated * 2;
        if (new_alloc > MAX_LINES) {
            new_alloc = MAX_LINES;
        }
        
        new_lines = (StringResource far *)xfarmalloc(new_alloc * sizeof(StringResource));
        if (!new_lines) {
            return 0; /* Out of memory */
        }
        
        if (section->lines) {
            _fmemcpy(new_lines, section->lines, 
                    section->line_count * sizeof(StringResource));
            xfarfree(section->lines);
        }
        
        section->lines = new_lines;
        section->lines_allocated = new_alloc;
    }
    
    if (section->line_count < section->lines_allocated) {
        res = &section->lines[section->line_count];
        res->key = key ? far_strdup(key) : NULL;
        res->value = value ? far_strdup(value) : NULL;
        res->condition = condition ? far_strdup(condition) : NULL;
        
        if ((!key || res->key) && (!value || res->value) && (!condition || res->condition)) {
            section->line_count++;
            return 1;
        } else {
            /* Cleanup if allocation failed */
            if (res->key) xfarfree(res->key);
            if (res->value) xfarfree(res->value);
            if (res->condition) xfarfree(res->condition);
            return 0;
        }
    }
    
    return 0;
}

/* Parser for file list sections (windows, windows.system, etc.) */
static void parse_file_list_section(const char* line, InfSection* section) {
    char key_buf[MAX_KEY_LENGTH];
    char value_buf[MAX_VALUE_LENGTH];
    char condition_buf[MAX_VALUE_LENGTH];
    char *comma_pos;
    char *temp;
    char *end_ptr;
    char line_copy[512];
    
    /* Initialize */
    key_buf[0] = '\0';
    value_buf[0] = '\0';
    condition_buf[0] = '\0';
    
    /* Create a copy we can modify */
    strncpy(line_copy, line, sizeof(line_copy)-1);
    line_copy[sizeof(line_copy)-1] = '\0';
    
    /* Trim leading and trailing whitespace */
    temp = line_copy;
    while (*temp && isspace((unsigned char)*temp)) temp++;
    if (temp != line_copy) {
        memmove(line_copy, temp, strlen(temp) + 1);
    }
    end_ptr = line_copy + strlen(line_copy) - 1;
    while (end_ptr > line_copy && isspace((unsigned char)*end_ptr)) {
        *end_ptr = '\0';
        end_ptr--;
    }
    
    /* Skip empty lines */
    if (strlen(line_copy) == 0) {
        return;
    }
    
    /* Find comma separator for condition */
    comma_pos = strchr(line_copy, ',');
    
    if (comma_pos != NULL) {
        /* Format: source,condition */
        *comma_pos = '\0';
        
        /* Source file (key) - part before comma */
        strncpy(key_buf, line_copy, MAX_KEY_LENGTH - 1);
        key_buf[MAX_KEY_LENGTH - 1] = '\0';
        
        /* Condition is after comma */
        strncpy(condition_buf, comma_pos + 1, MAX_VALUE_LENGTH - 1);
        condition_buf[MAX_VALUE_LENGTH - 1] = '\0';
    } else {
        /* Format: source (no condition) */
        strncpy(key_buf, line_copy, MAX_KEY_LENGTH - 1);
        key_buf[MAX_KEY_LENGTH - 1] = '\0';
    }
    
    /* Remove disk prefixes from key */
    remove_disk_prefix(key_buf);
    
    /* Trim whitespace from key */
    temp = key_buf;
    while (*temp && isspace((unsigned char)*temp)) temp++;
    if (temp != key_buf) {
        memmove(key_buf, temp, strlen(temp) + 1);
    }
    end_ptr = key_buf + strlen(key_buf) - 1;
    while (end_ptr > key_buf && isspace((unsigned char)*end_ptr)) {
        *end_ptr = '\0';
        end_ptr--;
    }
    
    /* For file list sections, value should be the same as key (same filename) */
    if (strlen(key_buf) > 0 && strlen(value_buf) == 0) {
        strcpy(value_buf, key_buf);
    }
    
    /* Trim whitespace from condition if present */
    if (condition_buf[0] != '\0') {
        temp = condition_buf;
        while (*temp && isspace((unsigned char)*temp)) temp++;
        if (temp != condition_buf) {
            memmove(condition_buf, temp, strlen(temp) + 1);
        }
        end_ptr = condition_buf + strlen(condition_buf) - 1;
        while (end_ptr > condition_buf && isspace((unsigned char)*end_ptr)) {
            *end_ptr = '\0';
            end_ptr--;
        }
    }
    
    /* Add to section if we have a valid key */
    if (strlen(key_buf) > 0) {
        add_section_line(section, key_buf, value_buf, condition_buf);
    }
}

/* Structure for machine configuration */
typedef struct {
    char description[256];
    char machine_id[50];
    char config[1024];
} CurrentMachine;

/* NEW: Completely rewritten machine section parser */
static void parse_machine_section(const char* line, InfSection* section) {
    static CurrentMachine current_machine = {0};
    static int in_machine_entry = 0;
    char *temp;
    char *end_ptr;
    char machine_line[512];
    char *first_quote;
    char *second_quote;
    char *third_quote;
    char *fourth_quote;
    int desc_len;
    int id_len;
    
    strncpy(machine_line, line, sizeof(machine_line)-1);
    machine_line[sizeof(machine_line)-1] = '\0';
    
    /* Trim leading and trailing whitespace */
    temp = machine_line;
    while (*temp && isspace((unsigned char)*temp)) temp++;
    end_ptr = machine_line + strlen(machine_line) - 1;
    while (end_ptr > machine_line && isspace((unsigned char)*end_ptr)) {
        *end_ptr = '\0';
        end_ptr--;
    }
    
    /* Skip empty lines and comments */
    if (strlen(machine_line) == 0 || machine_line[0] == ';') {
        return;
    }
    
    /* Check if this is a new machine entry (starts with quote) */
    if (machine_line[0] == '"') {
        /* If we were already processing a machine, save it first */
        if (in_machine_entry && strlen(current_machine.description) > 0) {
            /* Add to section */
            add_section_line(section, current_machine.description, current_machine.config, NULL);
            
            /* Log the machine entry */
            log_message("Added machine: %s -> %s", current_machine.description, current_machine.config);
        }
        
        /* Start new machine entry */
        memset(&current_machine, 0, sizeof(current_machine));
        in_machine_entry = 1;
        
        /* Parse the description line */
        first_quote = machine_line;
        second_quote = strchr(first_quote + 1, '"');
        if (second_quote != NULL) {
            /* Extract description between first and second quote */
            desc_len = second_quote - (first_quote + 1);
            if (desc_len > 0 && desc_len < (int)sizeof(current_machine.description)) {
                strncpy(current_machine.description, first_quote + 1, desc_len);
                current_machine.description[desc_len] = '\0';
            }
            
            /* Look for machine ID after the description */
            third_quote = strchr(second_quote + 1, '"');
            if (third_quote != NULL) {
                fourth_quote = strchr(third_quote + 1, '"');
                if (fourth_quote != NULL) {
                    /* Machine ID found between third and fourth quote */
                    id_len = fourth_quote - (third_quote + 1);
                    if (id_len > 0 && id_len < (int)sizeof(current_machine.machine_id)) {
                        strncpy(current_machine.machine_id, third_quote + 1, id_len);
                        current_machine.machine_id[id_len] = '\0';
                    }
                }
            }
            
            /* Parse configuration from the rest of the line */
            {
                char *config_start = second_quote + 1;
                
                if (third_quote != NULL && fourth_quote != NULL) {
                    config_start = fourth_quote + 1;
                }
                
                /* Skip whitespace */
                while (*config_start && isspace((unsigned char)*config_start)) config_start++;
                
                /* Remove comments */
                {
                    char *comment_pos = strchr(config_start, ';');
                    if (comment_pos != NULL) {
                        *comment_pos = '\0';
                    }
                }
                
                /* Trim trailing whitespace from config */
                end_ptr = config_start + strlen(config_start) - 1;
                while (end_ptr > config_start && isspace((unsigned char)*end_ptr)) {
                    *end_ptr = '\0';
                    end_ptr--;
                }
                
                /* Add to config if not empty */
                if (strlen(config_start) > 0) {
                    if (strlen(current_machine.config) > 0) {
                        strcat(current_machine.config, " ");
                    }
                    strcat(current_machine.config, config_start);
                }
            }
        }
    } else {
        /* This is a continuation line for the current machine */
        if (in_machine_entry) {
            char config_line[512];
            strncpy(config_line, machine_line, sizeof(config_line)-1);
            config_line[sizeof(config_line)-1] = '\0';
            
            /* Remove comments */
            {
                char *comment_pos = strchr(config_line, ';');
                if (comment_pos != NULL) {
                    *comment_pos = '\0';
                }
            }
            
            /* Trim */
            temp = config_line;
            while (*temp && isspace((unsigned char)*temp)) temp++;
            end_ptr = config_line + strlen(config_line) - 1;
            while (end_ptr > config_line && isspace((unsigned char)*end_ptr)) {
                *end_ptr = '\0';
                end_ptr--;
            }
            
            /* Add to config if not empty */
            if (strlen(config_line) > 0) {
                if (strlen(current_machine.config) > 0) {
                    strcat(current_machine.config, " ");
                }
                strcat(current_machine.config, config_line);
            }
        }
    }
}

/* Parser for disks section */
static void parse_disks_section(const char* line, InfSection* section) {
    char *equal_sign;
    char disk_char;
    char *path_start;
    char *comma1;
    char *comma2;
    char *label_start;
    char *tag_start;
    char path[300];
    char label[300];
    char tag[300];
    char *temp;
    char *end_ptr;
    char disk_line[512];
    char disk_key[10];
    char disk_value[300];
    
    strncpy(disk_line, line, sizeof(disk_line)-1);
    disk_line[sizeof(disk_line)-1] = '\0';
    
    /* Skip lines that don't have equals sign */
    equal_sign = strchr(disk_line, '=');
    if (!equal_sign) return;
    
    /* Get disk character (should be first character) */
    disk_char = disk_line[0];
    if (!isalnum((unsigned char)disk_char)) {
        return;
    }
    
    /* Skip whitespace after disk char and before = */
    temp = disk_line + 1;
    while (*temp && isspace((unsigned char)*temp) && temp < equal_sign) temp++;
    
    /* Skip whitespace after = */
    path_start = equal_sign + 1;
    while (*path_start && isspace((unsigned char)*path_start)) path_start++;
    
    /* Find first comma */
    comma1 = strchr(path_start, ',');
    if (!comma1) return;
    *comma1 = '\0';
    
    /* Find second comma */
    comma2 = strchr(comma1 + 1, ',');
    if (!comma2) return;
    *comma2 = '\0';
    
    /* Extract path, label, and tag */
    strncpy(path, path_start, sizeof(path)-1);
    path[sizeof(path)-1] = '\0';
    
    label_start = comma1 + 1;
    while (*label_start && isspace((unsigned char)*label_start)) label_start++;
    strncpy(label, label_start, sizeof(label)-1);
    label[sizeof(label)-1] = '\0';
    
    tag_start = comma2 + 1;
    while (*tag_start && isspace((unsigned char)*tag_start)) tag_start++;
    strncpy(tag, tag_start, sizeof(tag)-1);
    tag[sizeof(tag)-1] = '\0';
    
    /* Remove quotes if present */
    if (label[0] == '"' && label[strlen(label)-1] == '"') {
        memmove(label, label+1, strlen(label)-2);
        label[strlen(label)-2] = '\0';
    }
    if (tag[0] == '"' && tag[strlen(tag)-1] == '"') {
        memmove(tag, tag+1, strlen(tag)-2);
        tag[strlen(tag)-2] = '\0';
    }
    
    /* Trim whitespace from all fields */
    temp = path;
    while (*temp && isspace((unsigned char)*temp)) temp++;
    if (temp != path) {
        strcpy(path, temp);
    }
    end_ptr = path + strlen(path) - 1;
    while (end_ptr > path && isspace((unsigned char)*end_ptr)) {
        *end_ptr = '\0';
        end_ptr--;
    }
    
    temp = label;
    while (*temp && isspace((unsigned char)*temp)) temp++;
    if (temp != label) {
        strcpy(label, temp);
    }
    end_ptr = label + strlen(label) - 1;
    while (end_ptr > label && isspace((unsigned char)*end_ptr)) {
        *end_ptr = '\0';
        end_ptr--;
    }
    
    temp = tag;
    while (*temp && isspace((unsigned char)*temp)) temp++;
    if (temp != tag) {
        strcpy(tag, temp);
    }
    end_ptr = tag + strlen(tag) - 1;
    while (end_ptr > tag && isspace((unsigned char)*end_ptr)) {
        *end_ptr = '\0';
        end_ptr--;
    }
    
    /* Add to disk info array */
    if (disk_count < MAX_DISKS) {
        disk_info[disk_count].disk = disk_char;
        strncpy(disk_info[disk_count].path, path, sizeof(disk_info[disk_count].path)-1);
        disk_info[disk_count].path[sizeof(disk_info[disk_count].path)-1] = '\0';
        strncpy(disk_info[disk_count].label, label, sizeof(disk_info[disk_count].label)-1);
        disk_info[disk_count].label[sizeof(disk_info[disk_count].label)-1] = '\0';
        strncpy(disk_info[disk_count].tag, tag, sizeof(disk_info[disk_count].tag)-1);
        disk_info[disk_count].tag[sizeof(disk_info[disk_count].tag)-1] = '\0';
        disk_count++;
        
        log_message("Added disk: %c -> %s, label: %s, tag: %s", disk_char, path, label, tag);
    }
    
    /* Also add to section as key-value pair */
    sprintf(disk_key, "%c", disk_char);
    sprintf(disk_value, "%s,%s,%s", path, label, tag);
    
    add_section_line(section, disk_key, disk_value, NULL);
}

/* Parser for generic key=value sections */
static void parse_generic_section(const char* line, InfSection* section) {
    char *equal_sign;
    char *key_ptr;
    char *value_ptr;
    char *temp;
    char *end_ptr;
    char generic_line[512];
    
    strncpy(generic_line, line, sizeof(generic_line)-1);
    generic_line[sizeof(generic_line)-1] = '\0';
    
    equal_sign = strchr(generic_line, '=');
    if (!equal_sign) return;
    
    *equal_sign = '\0';
    key_ptr = generic_line;
    value_ptr = equal_sign + 1;
    
    /* Trim whitespace from key */
    while (*key_ptr && isspace((unsigned char)*key_ptr)) key_ptr++;
    temp = key_ptr + strlen(key_ptr) - 1;
    while (temp > key_ptr && isspace((unsigned char)*temp)) {
        *temp = '\0';
        temp--;
    }
    
    /* Trim whitespace from value */
    while (*value_ptr && isspace((unsigned char)*value_ptr)) value_ptr++;
    end_ptr = value_ptr + strlen(value_ptr) - 1;
    while (end_ptr > value_ptr && isspace((unsigned char)*end_ptr)) {
        *end_ptr = '\0';
        end_ptr--;
    }
    
    /* Remove quotes from value if present */
    if (value_ptr[0] == '"' && value_ptr[strlen(value_ptr)-1] == '"') {
        memmove(value_ptr, value_ptr+1, strlen(value_ptr)-2);
        value_ptr[strlen(value_ptr)-2] = '\0';
    }
    
    /* Skip if key is empty */
    if (strlen(key_ptr) == 0) {
        return;
    }
    
    /* Add to section */
    add_section_line(section, key_ptr, value_ptr, NULL);
}

/* Finalize any pending machine entry at the end of file */
static void finalize_machine_section(InfSection* section) {
    static CurrentMachine current_machine = {0};
    static int in_machine_entry = 0;
    
    if (in_machine_entry && strlen(current_machine.description) > 0) {
        /* Add to section */
        add_section_line(section, current_machine.description, current_machine.config, NULL);
        
        /* Log the machine entry */
        log_message("Added machine: %s -> %s", current_machine.description, current_machine.config);
        
        /* Reset for next time */
        memset(&current_machine, 0, sizeof(current_machine));
        in_machine_entry = 0;
    }
}

/* FIXED: Parse machine configuration into structured fields */
static void parse_machine_configuration(const char far *config_str, MachineEntry* entry) {
    char* config_copy;
    char* token;
    int field_index;
    int i;
    unsigned int len;
    const char far *p;
    const char far *src;
    char *dst;
    
    /* Initialize variables */
    config_copy = NULL;
    token = NULL;
    field_index = 0;
    
    /* Initialize machine entry */
    entry->system_drv = NULL;
    entry->kbd_drv = NULL;
    entry->kbd_type = NULL;
    entry->mouse_drv = NULL;
    entry->disp_drv = NULL;
    entry->sound_drv = NULL;
    entry->comm_drv = NULL;
    entry->himem_switch = NULL;
    entry->ebios = NULL;
    entry->cookie_count = 0;
    for (i = 0; i < 20; i++) {
        entry->cookies[i] = NULL;
    }
    
    if (!config_str) {
        return;
    }
    
    /* Create a near copy for parsing */
    /* Calculate length manually */
    len = 0;
    p = config_str;
    while (*p) {
        len++;
        p++;
    }
    
    config_copy = (char*)xmalloc(len + 1);
    if (!config_copy) {
        return;
    }
    
    /* Copy string manually */
    src = config_str;
    dst = config_copy;
    for (i = 0; i < len; i++) {
        *dst++ = *src++;
    }
    *dst = '\0';
    
    /* Parse tokens separated by spaces */
    token = strtok(config_copy, " \t");
    while (token != NULL) {
        /* Skip empty tokens */
        if (strlen(token) == 0) {
            token = strtok(NULL, " \t");
            continue;
        }
        
        /* Assign to structured fields based on position */
        switch (field_index) {
            case 0:
                entry->system_drv = far_strdup(token);
                break;
            case 1:
                entry->kbd_drv = far_strdup(token);
                break;
            case 2:
                entry->kbd_type = far_strdup(token);
                break;
            case 3:
                entry->mouse_drv = far_strdup(token);
                break;
            case 4:
                entry->disp_drv = far_strdup(token);
                break;
            case 5:
                entry->sound_drv = far_strdup(token);
                break;
            case 6:
                entry->comm_drv = far_strdup(token);
                break;
            case 7:
                entry->himem_switch = far_strdup(token);
                break;
            case 8:
                entry->ebios = far_strdup(token);
                break;
            default:
                /* Additional parameters go to cookies */
                if (entry->cookie_count < 20) {
                    entry->cookies[entry->cookie_count] = far_strdup(token);
                    entry->cookie_count++;
                }
                break;
        }
        
        field_index++;
        token = strtok(NULL, " \t");
    }
    
    xfree(config_copy);
}

/* FIXED: Get parsed machine entry by index */
MachineEntry* get_machine_entry(int index) {
    if (index >= 0 && index < machine_entry_count) {
        return &machine_entries[index];
    }
    return NULL;
}

/* FIXED: Free machine entry resources */
void free_machine_entry(MachineEntry* entry) {
    int i;
    
    if (!entry) return;
    
    if (entry->system_drv) xfarfree(entry->system_drv);
    if (entry->kbd_drv) xfarfree(entry->kbd_drv);
    if (entry->kbd_type) xfarfree(entry->kbd_type);
    if (entry->mouse_drv) xfarfree(entry->mouse_drv);
    if (entry->disp_drv) xfarfree(entry->disp_drv);
    if (entry->sound_drv) xfarfree(entry->sound_drv);
    if (entry->comm_drv) xfarfree(entry->comm_drv);
    if (entry->himem_switch) xfarfree(entry->himem_switch);
    if (entry->ebios) xfarfree(entry->ebios);
    
    for (i = 0; i < entry->cookie_count; i++) {
        if (entry->cookies[i]) xfarfree(entry->cookies[i]);
    }
    
    entry->cookie_count = 0;
}

/* FIXED: Parse all machine entries during INF loading */
static void parse_all_machine_entries(void) {
    InfSection* machine_section;
    int i;
    
    /* Free existing machine entries */
    for (i = 0; i < machine_entry_count; i++) {
        free_machine_entry(&machine_entries[i]);
    }
    machine_entry_count = 0;
    
    machine_section = get_section("machine");
    if (!machine_section) {
        return;
    }
    
    machine_entry_count = machine_section->line_count;
    if (machine_entry_count > MAX_SECTIONS) {
        machine_entry_count = MAX_SECTIONS;
    }
    
    for (i = 0; i < machine_entry_count; i++) {
        parse_machine_configuration(machine_section->lines[i].value, &machine_entries[i]);
    }
    
    log_message("Parsed %d machine entries", machine_entry_count);
}

void load_inf_file(const char* filename) {
    FILE* file;
    char line[512];
    char current_section[100] = "";
    InfSection* current_section_ptr = NULL;
    char* pos;
    char* trimmed_line;
    char* end_ptr;
    int i;
    int j;
    int section_index;
    
    log_message("Loading INF file: %s", filename);
    
    /* Clear existing sections */
    for (i = 0; i < section_count; i++) {
        if (sections[i].lines) {
            for (j = 0; j < sections[i].line_count; j++) {
                if (sections[i].lines[j].key) {
                    xfarfree(sections[i].lines[j].key);
                }
                if (sections[i].lines[j].value) {
                    xfarfree(sections[i].lines[j].value);
                }
                if (sections[i].lines[j].condition) {
                    xfarfree(sections[i].lines[j].condition);
                }
            }
            xfarfree(sections[i].lines);
        }
    }
    section_count = 0;
    disk_count = 0;
    
    file = fopen(filename, "rt");
    if (!file) {
        log_message("Error: Cannot open INF file: %s", filename);
        return;
    }

    while (fgets(line, sizeof(line), file)) {
        /* Remove newline characters */
        line[strcspn(line, "\r\n")] = '\0';
        
        /* Trim leading and trailing whitespace */
        trimmed_line = line;
        while (*trimmed_line && isspace((unsigned char)*trimmed_line)) trimmed_line++;
        end_ptr = trimmed_line + strlen(trimmed_line) - 1;
        while (end_ptr > trimmed_line && isspace((unsigned char)*end_ptr)) {
            *end_ptr = '\0';
            end_ptr--;
        }
        
        /* Skip empty lines and comments */
        if (trimmed_line[0] == '\0' || trimmed_line[0] == ';') {
            continue;
        }

        /* Check for section header */
        if (trimmed_line[0] == '[') {
            /* Finalize any pending machine section */
            if (strcmp(current_section, "machine") == 0) {
                finalize_machine_section(current_section_ptr);
            }
            
            pos = strchr(trimmed_line, ']');
            if (pos) {
                *pos = '\0';
                strncpy(current_section, trimmed_line + 1, sizeof(current_section) - 1);
                current_section[sizeof(current_section) - 1] = '\0';
                
                log_message("Found section: [%s]", current_section);
                
                /* Find or create section */
                current_section_ptr = NULL;
                for (section_index = 0; section_index < section_count; section_index++) {
                    if (strcmp(sections[section_index].name, current_section) == 0) {
                        current_section_ptr = &sections[section_index];
                        break;
                    }
                }
                
                if (!current_section_ptr && section_count < MAX_SECTIONS) {
                    current_section_ptr = &sections[section_count];
                    strncpy(current_section_ptr->name, current_section, 
                           sizeof(current_section_ptr->name) - 1);
                    current_section_ptr->name[sizeof(current_section_ptr->name) - 1] = '\0';
                    current_section_ptr->lines = NULL;
                    current_section_ptr->line_count = 0;
                    current_section_ptr->lines_allocated = 0;
                    section_count++;
                    log_message("Created new section: [%s], total sections: %d", current_section, section_count);
                }
            }
            continue;
        }

        /* Process line based on current section type */
        if (current_section_ptr) {
            if (strcmp(current_section, "disks") == 0) {
                parse_disks_section(trimmed_line, current_section_ptr);
            } else if (strcmp(current_section, "machine") == 0) {
                parse_machine_section(trimmed_line, current_section_ptr);
            } else if (strcmp(current_section, "windows.system") == 0 ||
                       strcmp(current_section, "windows") == 0 ||
                       strcmp(current_section, "windows.system.386") == 0) {
                parse_file_list_section(trimmed_line, current_section_ptr);
            } else {
                parse_generic_section(trimmed_line, current_section_ptr);
            }
        }
    }
    
    /* Finalize any pending machine section at end of file */
    if (strcmp(current_section, "machine") == 0) {
        finalize_machine_section(current_section_ptr);
    }
    
    fclose(file);
    
    /* FIXED: Parse all machine entries after loading INF file */
    parse_all_machine_entries();
    
    log_message("Finished loading INF file. Total sections: %d", section_count);
    
    /* Debug: list all loaded sections */
    for (i = 0; i < section_count; i++) {
        log_message("Section [%s] has %d entries", sections[i].name, sections[i].line_count);
    }
}

char* get_string(const char* section, const char* key) {
    return get_string_default(section, key, NULL);
}

char* get_string_default(const char* section, const char* key, const char* default_value) {
    int i;
    int j;
    StringResource far *res;
    char* result;
    unsigned int len;
    const char far *src;
    char *dst;
    
    for (i = 0; i < section_count; i++) {
        if (strcmp(sections[i].name, section) == 0) {
            for (j = 0; j < sections[i].line_count; j++) {
                res = &sections[i].lines[j];
                if (res->key && _fstrcmp(res->key, (const char far *)key) == 0) {
                    len = _fstrlen(res->value);
                    result = (char*)xmalloc(len + 1);
                    if (result) {
                        /* Copy from far to near memory */
                        src = res->value;
                        dst = result;
                        while (len--) {
                            *dst++ = *src++;
                        }
                        *dst = '\0';
                    }
                    return result;
                }
            }
            break;
        }
    }
    
    if (default_value) {
        result = (char*)xmalloc(strlen(default_value) + 1);
        if (result) {
            strcpy(result, default_value);
        }
        return result;
    }
    
    return NULL;
}

char* get_string_for_cpu(const char* base_section, const char* key, int cpu_type) {
    char section_name[100];
    char* result;
    
    if (cpu_type == CPU_386) {
        sprintf(section_name, "%s.win386", base_section);
        result = get_string(section_name, key);
        if (result) return result;
        
        sprintf(section_name, "%s.386", base_section);
        result = get_string(section_name, key);
        if (result) return result;
    } else if (cpu_type == CPU_286) {
        sprintf(section_name, "%s.286", base_section);
        result = get_string(section_name, key);
        if (result) return result;
    }
    
    return get_string(base_section, key);
}

int get_int(const char* section, const char* key, int default_value) {
    char* str_val;
    int result;
    
    str_val = get_string(section, key);
    if (str_val) {
        result = atoi(str_val);
        xfree(str_val);
        return result;
    }
    return default_value;
}

DiskInfo* get_disk_info(char disk) {
    int i;
    
    for (i = 0; i < disk_count; i++) {
        if (disk_info[i].disk == disk) {
            return &disk_info[i];
        }
    }
    
    return NULL;
}

char* get_disk_path(char disk) {
    DiskInfo* info;
    char* result;
    
    info = get_disk_info(disk);
    if (info && info->path[0]) {
        result = (char*)xmalloc(strlen(info->path) + 1);
        if (result) {
            strcpy(result, info->path);
        }
        return result;
    }
    return NULL;
}

char* get_disk_label(char disk) {
    DiskInfo* info;
    char* result;
    
    info = get_disk_info(disk);
    if (info && info->label[0]) {
        result = (char*)xmalloc(strlen(info->label) + 1);
        if (result) {
            strcpy(result, info->label);
        }
        return result;
    }
    return NULL;
}

char* get_disk_tag(char disk) {
    DiskInfo* info;
    char* result;
    
    info = get_disk_info(disk);
    if (info && info->tag[0]) {
        result = (char*)xmalloc(strlen(info->tag) + 1);
        if (result) {
            strcpy(result, info->tag);
        }
        return result;
    }
    return NULL;
}

char* get_current_language(void) {
    char* result;
    
    result = (char*)xmalloc(strlen(current_language) + 1);
    if (result) {
        strcpy(result, current_language);
    }
    return result;
}

InfSection* get_section(const char* section_name) {
    int i;
    
    for (i = 0; i < section_count; i++) {
        if (strcmp(sections[i].name, section_name) == 0) {
            return &sections[i];
        }
    }
    return NULL;
}

void free_resources(void) {
    int i;
    int j;
    StringResource far *res;
    
    for (i = 0; i < section_count; i++) {
        if (sections[i].lines) {
            for (j = 0; j < sections[i].line_count; j++) {
                res = &sections[i].lines[j];
                if (res->key) xfarfree(res->key);
                if (res->value) xfarfree(res->value);
                if (res->condition) xfarfree(res->condition);
            }
            xfarfree(sections[i].lines);
            sections[i].lines = NULL;
        }
        sections[i].line_count = 0;
        sections[i].lines_allocated = 0;
    }
    section_count = 0;
    disk_count = 0;
    
    /* FIXED: Free machine entries */
    for (i = 0; i < machine_entry_count; i++) {
        free_machine_entry(&machine_entries[i]);
    }
    machine_entry_count = 0;
}

int get_section_count(void) {
    return section_count;
}

char* get_private_profile_string(const char* section, const char* key, 
                                const char* default_val, const char* filename) {
    /* For now, use the already loaded INF file data */
    return get_string_default(section, key, default_val);
}

int get_private_profile_int(const char* section, const char* key, 
                           int default_val, const char* filename) {
    char* str_val;
    int result;
    
    str_val = get_private_profile_string(section, key, NULL, filename);
    if (str_val) {
        result = atoi(str_val);
        xfree(str_val);
        return result;
    }
    return default_val;
}
